<?php
declare(strict_types=1);

function role_attention_items(?PDO $db,array $account,string $requestPath): array
{
    if(!$db)return [[],[]];
    $role=($account['role']??'examinee')==='examinee'?'candidate':($account['role']??'candidate');
    $candidates=[];
    try{
        if($role==='admin'){
            $pendingPdf=$db->query("SELECT COALESCE(MAX(id),0) latest,COUNT(*) total FROM pdf_files WHERE status='review' OR rights_status='pending'")->fetch();
            $pendingApps=table_exists($db,'eligibility_applications')?$db->query("SELECT COALESCE(MAX(id),0) latest,COUNT(*) total FROM eligibility_applications WHERE status IN ('pending','needs_revision')")->fetch():['latest'=>0,'total'=>0];
            $candidates[]=['key'=>'admin_pdfs','href'=>'admin/manage-pdfs.php','match'=>'/admin/manage-pdfs.php','label'=>'PDF review','message'=>((int)$pendingPdf['total']).' PDF submission'.((int)$pendingPdf['total']===1?'':'s').' awaiting review.','latest'=>(int)$pendingPdf['latest'],'count'=>(int)$pendingPdf['total']];
            $candidates[]=['key'=>'admin_applications','href'=>'admin/applications.php','match'=>'/admin/applications.php','label'=>'Applications','message'=>((int)$pendingApps['total']).' application'.((int)$pendingApps['total']===1?'':'s').' awaiting approval.','latest'=>(int)$pendingApps['latest'],'count'=>(int)$pendingApps['total']];
        }elseif($role==='contributor'&&table_exists($db,'earnings_ledger')){
            $profile=active_profile();$sale=['latest'=>0,'total'=>0];
            if($profile){$q=$db->prepare("SELECT COALESCE(MAX(id),0) latest,COUNT(*) total FROM earnings_ledger WHERE contributor_profile_id=? AND entry_type='sale'");$q->execute([(int)$profile['id']]);$sale=$q->fetch();}
            $candidates[]=['key'=>'contributor_sales','href'=>'contributor/dashboard.php','match'=>'/contributor/dashboard.php','label'=>'New purchases','message'=>((int)$sale['total']).' confirmed purchase'.((int)$sale['total']===1?'':'s').' recorded for your reviewers.','latest'=>(int)$sale['latest'],'count'=>(int)$sale['total']];
        }else{
            $published=$db->query("SELECT COALESCE(MAX(id),0) latest,COUNT(*) total FROM pdf_files WHERE status='published'")->fetch();
            $candidates[]=['key'=>'candidate_pdfs','href'=>'dashboard.php','match'=>'/dashboard.php','label'=>'New reviewers','message'=>((int)$published['total']).' reviewer'.((int)$published['total']===1?' is':'s are').' available on your dashboard.','latest'=>(int)$published['latest'],'count'=>(int)$published['total']];
        }
    }catch(Throwable $e){return [[],[]];}
    $items=[];$opened=[];$_SESSION['attention_seen']=$_SESSION['attention_seen']??[];
    foreach($candidates as $item){
        if($item['count']<1||$item['latest']<1)continue;
        $seen=(int)($_SESSION['attention_seen'][$item['key']]??0);
        $isDestination=str_ends_with($requestPath,$item['match']);
        $item['unread']=$item['latest']>$seen;
        if($item['unread']&&$isDestination){$_SESSION['attention_seen'][$item['key']]=$item['latest'];$opened[]=$item['message'];$item['unread']=false;}
        $items[]=$item;
    }
    return [$items,$opened];
}

function page_start(string $title, string $mode = 'app'): void
{
    $current = basename($_SERVER['PHP_SELF'] ?? '');
    $account = user();
    $flashes = consume_flashes();
    $attentionItems=[];$openedAttention=[];
    if($mode==='app'){$requestPath=str_replace('\\','/',(string)(parse_url($_SERVER['PHP_SELF']??'',PHP_URL_PATH)??''));[$attentionItems,$openedAttention]=role_attention_items(Database::connection(),$account,$requestPath);}
    $linkedStatus=null;
    if($mode==='app'&&($account['role']??'')!=='admin'){$db=Database::connection();if($db&&table_exists($db,'role_profiles')){$currentRole=($account['role']??'examinee')==='examinee'?'candidate':$account['role'];$other=$currentRole==='candidate'?'contributor':'candidate';$q=$db->prepare('SELECT status FROM role_profiles WHERE user_id=? AND role=? LIMIT 1');$q->execute([(int)$account['id'],$other]);$linkedStatus=$q->fetchColumn()?:null;if(!$linkedStatus&&table_exists($db,'eligibility_applications')){$q=$db->prepare('SELECT status FROM eligibility_applications WHERE user_id=? AND requested_role=? ORDER BY id DESC LIMIT 1');$q->execute([(int)$account['id'],$other]);$linkedStatus=$q->fetchColumn()?:null;}}}
    ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
    <meta name="theme-color" content="#790D16">
    <meta name="description" content="REPASO secure reviewer platform for board examination candidates.">
    <title><?= e($title) ?> · REPASO</title>
    <link rel="manifest" href="<?= e(url('manifest.json')) ?>">
    <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='13' fill='%23790D16'/%3E%3Cpath d='M16 12h20c8 0 14 6 14 14s-6 14-14 14H26v12H16z' fill='%23E5D3AF'/%3E%3Cpath d='M26 21h10c3 0 5 2 5 5s-2 5-5 5H26z' fill='%23F5EFE1'/%3E%3C/svg%3E">
    <link rel="stylesheet" href="<?= e(asset('css/app.css')) ?>">
</head>
<body class="mode-<?= e($mode) ?>">
<?php foreach ($flashes as $flash): ?><div class="notification-seed hidden" data-notification data-notification-type="<?=e($flash['type'])?>" data-notification-title="<?=e(ucfirst($flash['type']))?>"><?=e($flash['message'])?></div><?php endforeach; ?>
<?php foreach ($openedAttention as $message): ?><div class="attention-toast" data-attention-toast><?=icon('bell',17)?><span><?=e($message)?></span><button type="button" data-attention-close aria-label="Dismiss">×</button></div><?php endforeach; ?>
<?php if ($mode === 'app'): ?>
<div class="app-shell">
    <aside class="sidebar" id="sidebar">
        <a class="brand brand-lockup" href="<?= e(url(role_home_path($account))) ?>" aria-label="REPASO dashboard"><img src="<?= e(asset('images/logo.jpg')) ?>" alt=""><span><strong>REPASO</strong><small>Your Digital Reviewer Hub.</small></span></a>
        <nav aria-label="Primary">
        <?php foreach (nav_items() as [$href,$iconName,$label]): $navAlert=null;foreach($attentionItems as $attention){if($attention['unread']&&$attention['href']===$href){$navAlert=$attention;break;}} ?>
            <a class="nav-link <?= $current === basename($href) ? 'active' : '' ?><?=$navAlert?' has-attention':''?>" href="<?= e(url($href)) ?>"><?= icon($iconName) ?><span><?= e($label) ?></span><?php if($navAlert):?><i class="attention-dot" aria-label="<?=e($navAlert['message'])?>"></i><?php endif;?></a>
        <?php endforeach; ?>
        </nav>
        <div class="sidebar-foot">
            <?php $displayRole=($account['role']??'examinee')==='examinee'?'candidate':($account['role']??'candidate'); if($displayRole==='candidate'):?><span class="plan-pill"><?= e(ucfirst($account['subscription'] ?? 'free')) ?> plan</span><?php elseif($displayRole==='contributor'):?><span class="plan-pill">Contributor profile</span><?php else:?><span class="plan-pill">Administrator</span><?php endif;?>
            <?php if($linkedStatus==='approved'):?><form method="post" action="<?=e(url('switch-profile.php'))?>" style="margin:8px 0"><?=csrf_field()?><input type="hidden" name="role" value="<?=$displayRole==='candidate'?'contributor':'candidate'?>"><button class="button ghost small block">Switch to <?=$displayRole==='candidate'?'Contributor':'Candidate'?></button></form><?php elseif($linkedStatus):?><span class="meta"><?=e(ucfirst(str_replace('_',' ',$displayRole==='candidate'?'contributor':'candidate')))?> application: <?=e(ucwords(str_replace('_',' ',$linkedStatus)))?></span><?php endif;?>
            <a class="nav-link" href="<?= e(url('logout.php')) ?>"><?= icon('lock') ?><span>Log out</span></a>
        </div>
    </aside>
    <div class="app-main">
        <header class="topbar">
            <button class="icon-button menu-button" data-sidebar-toggle aria-label="Open navigation"><?= icon('menu',22) ?></button>
            <div class="top-search"><?= icon('search') ?><input type="search" placeholder="Search reviewers, topics, or keywords" data-global-search></div>
            <?php $unreadAttention=array_values(array_filter($attentionItems,static fn($item)=>(bool)$item['unread']));?>
            <div class="attention-menu"><button class="icon-button" data-attention-toggle aria-label="Notifications" aria-expanded="false"><?= icon('bell',20) ?><?php if($unreadAttention):?><span class="notification-dot attention-dot-red"></span><?php endif;?></button><div class="attention-panel" data-attention-panel hidden><div class="attention-panel-head"><strong>Notifications</strong><span><?=count($unreadAttention)?> new</span></div><?php if($unreadAttention):?><?php foreach($unreadAttention as $item):?><a href="<?=e(url($item['href']))?>"><i></i><span><strong><?=e($item['label'])?></strong><small><?=e($item['message'])?></small></span></a><?php endforeach;?><?php else:?><div class="attention-empty"><?=icon('check',20)?><span>You're all caught up.</span></div><?php endif;?></div></div>
            <a class="profile-chip" href="<?= e(url('profile.php')) ?>"><?=profile_avatar($account,'profile-avatar')?><strong><?= e(first_name($account['fullname'] ?? 'User')) ?></strong></a>
        </header>
        <main class="content">
<?php elseif ($mode === 'public'): ?>
    <header class="public-header">
        <a class="brand brand-lockup" href="<?= e(url('index.php')) ?>"><img src="<?= e(asset('images/logo.jpg')) ?>" alt=""><span><strong>REPASO</strong><small>Your Digital Reviewer Hub.</small></span></a>
        <button class="icon-button public-menu" data-public-menu aria-label="Open menu"><?= icon('menu',22) ?></button>
        <nav class="public-nav" aria-label="Main navigation"><a href="<?= e(url('index.php')) ?>">Home</a><a href="<?= e(url('index.php#features')) ?>">Features</a><a href="<?= e(url('pricing.php')) ?>">Pricing</a><a href="<?= e(url('index.php#about')) ?>">About</a><a class="button ghost small" href="<?= e(url('login.php')) ?>">Log in</a><a class="button navy small" href="<?= e(url('register.php')) ?>">Sign up</a></nav>
    </header><main>
<?php else: ?><main class="auth-page">
<?php endif;
}

function page_end(string $mode = 'app'): void
{
    if ($mode === 'app') {
        $current = basename($_SERVER['PHP_SELF'] ?? '');
        echo '</main></div></div><nav class="mobile-nav" aria-label="Mobile navigation">';
        $role = user()['role'] ?? 'examinee';
        $mobile = $role==='admin' ? [['admin/dashboard.php','home','Overview'],['admin/manage-pdfs.php','library','PDFs'],['admin/system-monitoring.php','shield','Monitor'],['profile.php','settings','Settings']] : ($role==='contributor' ? [['contributor/dashboard.php','home','Home'],['contributor/upload.php','upload','Upload'],['library.php','library','Library'],['contributor/reports.php','chart','Reports'],['profile.php','settings','Profile']] : [['dashboard.php','home','Home'],['library.php','library','Library'],['offline.php','offline','Offline'],['progress.php','chart','Progress'],['profile.php','settings','Profile']]);
        foreach ($mobile as [$href,$iconName,$label]) {
            echo '<a class="'.($current===basename($href)?'active':'').'" href="'.e(url($href)).'">'.icon($iconName).'<span>'.e($label).'</span></a>';
        }
        echo '</nav>';
    }
    else echo '</main>';
    ?>
<script>window.REPASO={base:<?= json_encode(url('')) ?>,csrf:<?= json_encode($_SESSION['csrf'] ?? '') ?>};</script>
<script src="<?= e(asset('js/app.js')) ?>" defer></script>
</body></html><?php
}

function initials(string $name): string
{
    $parts = preg_split('/\s+/', trim($name)) ?: [];
    return strtoupper(substr($parts[0] ?? 'U',0,1) . substr(end($parts) ?: '',0,1));
}

function first_name(string $name): string
{
    return explode(' ', trim($name))[0] ?: 'User';
}
