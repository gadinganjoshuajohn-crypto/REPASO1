<?php
declare(strict_types=1);
function published_catalog_cards(array $rows,string $editPath,string $deletePath): void
{
    if(!$rows){echo '<div class="empty-state"><h2>No published reviewers yet</h2><p>Approved materials will appear here.</p></div>';return;}
    echo '<section class="catalog-grid managed-catalog">';
    foreach($rows as $r){$id=(int)$r['id'];$title=e($r['title']);$active=(int)($r['active_access']??0);echo '<article class="catalog-card" data-managed-card><div class="catalog-cover-wrap"><a class="catalog-cover-link" href="'.e(url('viewer.php?id='.$id)).'">'.reviewer_cover($r).'<span class="access-chip">'.e(pdf_is_repaso_owned($r)?'REPASO OWNED':ucwords(str_replace('_',' ',$r['access_policy']))).'</span></a><button type="button" class="cover-action" data-card-menu-button aria-label="Manage '.$title.'" aria-haspopup="menu" aria-expanded="false">•••</button><div class="card-action-menu" role="menu" hidden><button type="button" role="menuitem" data-confirm-edit data-title="'.$title.'" data-href="'.e(url($editPath.'?id='.$id)).'">Edit</button><button type="button" role="menuitem" class="danger" data-confirm-delete data-title="'.$title.'" data-active-access="'.$active.'">Delete</button></div><form method="post" action="'.e(url($deletePath)).'" data-archive-form>'.csrf_field().'<input type="hidden" name="id" value="'.$id.'"></form></div><div class="catalog-copy"><span class="badge">'.e(($r['profession']??'Reviewer').' · '.($r['subject']??'')).'</span><h2><a href="'.e(url('viewer.php?id='.$id)).'">'.$title.'</a></h2><p class="book-meta">By '.e(pdf_attribution($r)).'</p><a class="text-action" href="'.e(url('viewer.php?id='.$id)).'">Open reviewer '.icon('chevron').'</a></div></article>';}
    echo '</section>';
}
