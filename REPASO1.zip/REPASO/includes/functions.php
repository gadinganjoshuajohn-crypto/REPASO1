<?php
declare(strict_types=1);

function url(string $path = ''): string
{
    $base = str_replace('/admin', '', str_replace('/contributor', '', str_replace('/api', '', REPASO_BASE)));
    return ($base ?: '') . '/' . ltrim($path, '/');
}

function asset(string $path): string
{
    $clean=ltrim($path,'/');
    $absolute=REPASO_ROOT.'/assets/'.$clean;
    $version=is_file($absolute)?(string)filemtime($absolute):'';
    return url('assets/'.$clean).($version!==''?'?v='.rawurlencode($version):'');
}

function e(?string $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function security_questions(): array
{
    return [
        'What was the name of your first pet?',
        'What is the name of the street you grew up on?',
        'What was your childhood nickname?',
        'What is your favorite book or movie as a child?',
        "What is your mother's maiden name?",
    ];
}

function canonical_security_answer(string $answer): string
{
    $answer=preg_replace('/\s+/u',' ',trim($answer))??trim($answer);
    return function_exists('mb_strtolower')?mb_strtolower($answer,'UTF-8'):strtolower($answer);
}

function catalog_title_case(string $value): string
{
    $value=preg_replace('/\s+/u',' ',trim($value))??trim($value);
    $value=preg_replace('/[\x00-\x1F\x7F]/u','',$value)??$value;
    if($value==='')return '';
    return function_exists('mb_convert_case')?mb_convert_case($value,MB_CASE_TITLE,'UTF-8'):ucwords(strtolower($value));
}

function resolve_contributor_profession(PDO $db,string $professionChoice,string $customProfession): int
{
    $customProfession=catalog_title_case($customProfession);
    $length=static fn(string $v):int=>function_exists('mb_strlen')?mb_strlen($v,'UTF-8'):strlen($v);
    if($professionChoice==='other'){
        if($length($customProfession)<2||$length($customProfession)>150)throw new RuntimeException('Enter a profession name between 2 and 150 characters.');
        $q=$db->prepare('SELECT id,is_active FROM professions WHERE LOWER(name)=LOWER(?) LIMIT 1');$q->execute([$customProfession]);$existing=$q->fetch();
        if($existing){if(!$existing['is_active'])throw new RuntimeException('That profession exists but is currently inactive. Ask the administrator to activate it.');$professionId=(int)$existing['id'];}
        else{$base=strtolower(trim(preg_replace('/[^a-z0-9]+/i','-',$customProfession),'-'))?:'profession';$slug=$base;$suffix=2;$q=$db->prepare('SELECT 1 FROM professions WHERE slug=?');while(true){$q->execute([$slug]);if(!$q->fetchColumn())break;$slug=$base.'-'.$suffix++;}$q=$db->prepare('INSERT INTO professions(name,slug,description,is_active) VALUES(?,?,?,1)');$q->execute([$customProfession,$slug,'Contributor-submitted catalog entry; review alongside the associated PDF.']);$professionId=(int)$db->lastInsertId();}
    }else{$professionId=(int)$professionChoice;$q=$db->prepare('SELECT 1 FROM professions WHERE id=? AND is_active=1');$q->execute([$professionId]);if(!$professionId||!$q->fetchColumn())throw new RuntimeException('Choose an active profession.');}
    return $professionId;
}

function resolve_contributor_catalog(PDO $db,string $professionChoice,string $subjectChoice,string $customProfession,string $customSubject): array
{
    $customSubject=catalog_title_case($customSubject);
    $length=static fn(string $v):int=>function_exists('mb_strlen')?mb_strlen($v,'UTF-8'):strlen($v);
    $professionId=resolve_contributor_profession($db,$professionChoice,$customProfession);
    if($professionChoice==='other')$subjectChoice='other';
    if($subjectChoice==='other'){
        if($length($customSubject)<2||$length($customSubject)>150)throw new RuntimeException('Enter a subject/category name between 2 and 150 characters.');
        $q=$db->prepare('SELECT id,is_active FROM subjects WHERE profession_id=? AND LOWER(subject_name)=LOWER(?) LIMIT 1');$q->execute([$professionId,$customSubject]);$existing=$q->fetch();
        if($existing){if(!$existing['is_active'])throw new RuntimeException('That subject/category exists but is currently inactive. Ask the administrator to activate it.');$subjectId=(int)$existing['id'];}
        else{$q=$db->prepare('INSERT INTO subjects(profession_id,category_id,subject_name,description,is_active) VALUES(?,(SELECT id FROM categories ORDER BY id LIMIT 1),?,?,1)');$q->execute([$professionId,$customSubject,'Contributor-submitted catalog entry; review alongside the associated PDF.']);$subjectId=(int)$db->lastInsertId();}
    }else{$subjectId=(int)$subjectChoice;$q=$db->prepare('SELECT 1 FROM subjects WHERE id=? AND profession_id=? AND is_active=1');$q->execute([$subjectId,$professionId]);if(!$subjectId||!$q->fetchColumn())throw new RuntimeException('Choose an active subject/category for the selected profession.');}
    return [$professionId,$subjectId];
}

function profile_avatar(array $account,string $class='avatar'): string
{
    $classes=e($class);
    if(!empty($account['profile_image'])){$src=e(url('uploads/profiles/'.basename((string)$account['profile_image'])));return '<span class="'.$classes.' has-photo"><img src="'.$src.'" alt="Profile picture of '.e($account['fullname']??'User').'"></span>';}
    return '<span class="'.$classes.'">'.e(initials($account['fullname']??'User')).'</span>';
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . e($_SESSION['csrf'] ?? '') . '">';
}

function verify_csrf(): void
{
    $sent = $_POST['csrf'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!is_string($sent) || !hash_equals($_SESSION['csrf'] ?? '', $sent)) {
        http_response_code(419);
        exit('Your session expired. Refresh and try again.');
    }
}

function redirect(string $path): never
{
    header('Location: ' . url($path));
    exit;
}

function user(): array
{
    return $_SESSION['user'] ?? [
        'id' => 1,
        'fullname' => 'Jana Dela Cruz',
        'email' => 'jana.delacruz@email.com',
        'role' => 'examinee',
        'subscription' => 'premium',
    ];
}

function require_login(): void
{
    if (empty($_SESSION['user']) && !defined('REPASO_DEMO')) {
        redirect('login.php');
    }
}

function require_role(string ...$roles): void
{
    $current = user();
    $role = ($current['role'] ?? '') === 'examinee' ? 'candidate' : ($current['role'] ?? '');
    $allowed = array_map(static fn(string $r): string => $r === 'examinee' ? 'candidate' : $r, $roles);
    if (!in_array($role, $allowed, true) && !defined('REPASO_DEMO')) {
        http_response_code(403);
        exit('Access denied.');
    }
}

function role_home_path(?array $account=null): string
{
    $account=$account??user();
    $role=($account['role']??'examinee')==='examinee'?'candidate':($account['role']??'candidate');
    return $role==='admin'?'admin/dashboard.php':($role==='contributor'?'contributor/dashboard.php':'dashboard.php');
}

function flash(string $type, string $message): void
{
    $_SESSION['flash'][] = compact('type', 'message');
}

function admin_audit_log(PDO $db,string $action,string $targetType,string $targetId,array $details=[]): void
{
    if(!table_exists($db,'admin_audit_log'))return;
    $q=$db->prepare('INSERT INTO admin_audit_log(admin_user_id,action,target_type,target_id,details,ip_address) VALUES(?,?,?,?,?,?)');
    $q->execute([(int)user()['id'],$action,$targetType,$targetId,$details?json_encode($details):null,$_SERVER['REMOTE_ADDR']??null]);
}

function consume_flashes(): array
{
    $flashes = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $flashes;
}

function json_input(): array
{
    $data = json_decode((string) file_get_contents('php://input'), true);
    return is_array($data) ? $data : [];
}

function json_response(array $payload, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_SLASHES);
    exit;
}

function table_exists(PDO $db, string $table): bool
{
    static $cache=[];
    if (array_key_exists($table,$cache)) return $cache[$table];
    try { $q=$db->prepare('SELECT 1 FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=? LIMIT 1');$q->execute([$table]);return $cache[$table]=(bool)$q->fetchColumn(); }
    catch(Throwable $e){ return $cache[$table]=false; }
}

function active_profile(): ?array
{
    $current=user();
    if (($current['role']??'')==='admin') return null;
    $role=($current['role']??'examinee')==='examinee'?'candidate':($current['role']??'candidate');
    $db=Database::connection();
    if(!$db||!table_exists($db,'role_profiles')) return ['id'=>(int)($current['id']??0),'user_id'=>(int)($current['id']??0),'role'=>$role,'status'=>'approved'];
    $stmt=$db->prepare('SELECT * FROM role_profiles WHERE user_id=? AND role=? AND status="approved" LIMIT 1');
    $stmt->execute([(int)$current['id'],$role]);
    return $stmt->fetch()?:null;
}

function require_approved_profile(string $role): array
{
    require_login(); require_role($role);
    $profile=active_profile();
    if(!$profile){http_response_code(403);exit('This profile is not approved and active.');}
    return $profile;
}

function catalog_options(bool $activeOnly=true): array
{
    $db=Database::connection(); if(!$db||!table_exists($db,'professions')) return [];
    $sql='SELECT p.id profession_id,p.name profession_name,s.id subject_id,s.subject_name,s.is_active subject_active,p.is_active profession_active FROM professions p LEFT JOIN subjects s ON s.profession_id=p.id'.($activeOnly?' AND s.is_active=1':'').' '.($activeOnly?'WHERE p.is_active=1 ':'').'ORDER BY p.name,s.subject_name';
    return $db->query($sql)->fetchAll();
}

function money_php(int $centavos): string { return '₱'.number_format($centavos/100,2); }
function manila_time(?string $utc): string
{
    if(!$utc)return '—';try{return (new DateTimeImmutable($utc,new DateTimeZone('UTC')))->setTimezone(new DateTimeZone('Asia/Manila'))->format('M j, Y g:i A');}catch(Throwable $e){return '—';}
}

function email_delivery_configured(): bool
{
    return (string)getenv('REPASO_SMTP_HOST')!==''&&(string)getenv('REPASO_MAIL_FROM')!=='';
}

function send_activation_email(string $recipient,string $name,string $token): bool
{
    $autoload=REPASO_ROOT.'/vendor/autoload.php';if(!email_delivery_configured()||!is_file($autoload))return false;require_once $autoload;
    try{$mail=new PHPMailer\PHPMailer\PHPMailer(true);$mail->isSMTP();$mail->Host=(string)getenv('REPASO_SMTP_HOST');$mail->Port=(int)(getenv('REPASO_SMTP_PORT')?:587);$mail->SMTPAuth=(string)getenv('REPASO_SMTP_USER')!=='';$mail->Username=(string)getenv('REPASO_SMTP_USER');$mail->Password=(string)getenv('REPASO_SMTP_PASS');$mail->SMTPSecure=PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;$mail->setFrom((string)getenv('REPASO_MAIL_FROM'),'REPASO');$mail->addAddress($recipient,$name);$mail->Subject='Activate your approved REPASO account';$base=rtrim((string)(getenv('REPASO_APP_URL')?:''),'/');$link=$base.'/activate.php?token='.rawurlencode($token);$mail->Body="Your REPASO application was approved. Activate your account within 24 hours: $link\n\nThis approval concerns access to REPASO, not official licensure examination eligibility.";return $mail->send();}catch(Throwable $e){error_log('[REPASO] Activation email failed: '.$e->getMessage());return false;}
}

function record_usage(PDO $db, int $pdfId, string $type, bool $commercial=false): void
{
    if(!table_exists($db,'usage_events')) return;
    $profile=active_profile(); $session=session_id();
    $bucket=$type==='reader_session'?date('Y-m-d-H'):(string)microtime(true);
    $key=hash('sha256',user()['id'].'|'.$pdfId.'|'.$type.'|'.$session.'|'.$bucket);
    $stmt=$db->prepare('INSERT IGNORE INTO usage_events(event_key,pdf_id,user_id,profile_id,event_type,session_key,is_commercial,occurred_at) VALUES(?,?,?,?,?,?,?,UTC_TIMESTAMP())');
    $stmt->execute([$key,$pdfId,(int)user()['id'],$profile['id']??null,$type,$session,$commercial?1:0]);
}

function can_access_pdf(PDO $db, array $pdf, bool $download=false): array
{
    $role=(user()['role']??'examinee')==='examinee'?'candidate':(user()['role']??'candidate');
    if($role==='admin') return [true,'admin_preview'];
    $profile=active_profile(); if(!$profile) return [false,'profile_not_approved'];
    if($role==='contributor') return [(int)$pdf['contributor_id']===(int)user()['id'],'contributor_self_preview'];
    if(($pdf['access_policy']??'subscription')==='free') return [true,'free'];
    // Paid grants must win over preview. The old ordering limited paid candidates to preview pages.
    if(table_exists($db,'pdf_entitlements')){
        $q=$db->prepare('SELECT 1 FROM pdf_entitlements WHERE candidate_profile_id=? AND pdf_id=? AND revoked_at IS NULL AND starts_at<=UTC_TIMESTAMP() AND (expires_at IS NULL OR expires_at>UTC_TIMESTAMP()) LIMIT 1');
        $q->execute([(int)$profile['id'],(int)$pdf['id']]); if($q->fetchColumn()) return [true,'individual'];
    }
    $policy=(string)($pdf['access_policy']??'subscription');
    if(in_array($policy,['subscription','subscription_or_individual'],true)&&!empty($pdf['subscription_included'])&&table_exists($db,'subscriptions')){
        $q=$db->prepare('SELECT 1 FROM subscriptions WHERE candidate_profile_id=? AND status="active" AND end_date>UTC_TIMESTAMP() LIMIT 1');
        $q->execute([(int)$profile['id']]); if($q->fetchColumn()) return [true,'subscription'];
    }
    if(!$download && (int)($pdf['free_pages']??0)>0) return [true,'preview'];
    return [false,'payment_required'];
}

function pdf_is_repaso_owned(array $pdf): bool
{
    return ($pdf['owner_type']??'')==='repaso'&&($pdf['ownership_status']??'')==='verified';
}

function pdf_attribution(array $pdf): string
{
    return pdf_is_repaso_owned($pdf)?'REPASO':(string)($pdf['contributor']??'Contributor');
}

function validated_pdf_upload(?array $file, ?int $selfId=null): array
{
    if(!$file||($file['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK)throw new RuntimeException('Choose a valid PDF file.');
    if((int)($file['size']??0)>50*1024*1024)throw new RuntimeException('The PDF exceeds the 50 MB upload limit.');
    $mime=(new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);$head=file_get_contents($file['tmp_name'],false,null,0,5);
    if($mime!=='application/pdf'||$head!=='%PDF-')throw new RuntimeException('Only valid PDF documents are accepted.');
    $hash=hash_file('sha256',$file['tmp_name']);$db=Database::connection();
    if($db){$sql='SELECT id FROM pdf_files WHERE content_sha256=?'.($selfId?' AND id<>?':'').' LIMIT 1';$q=$db->prepare($sql);$args=[$hash];if($selfId)$args[]=$selfId;$q->execute($args);if($q->fetchColumn())throw new RuntimeException('This PDF already exists in REPASO. The existing listing can be reviewed for an ownership transfer.');}
    return [$hash,(string)$file['tmp_name']];
}

function pdf_cover_schema_ready(PDO $db): bool
{
    static $ready;
    if ($ready !== null) return $ready;
    try {
        $stmt=$db->query("SHOW COLUMNS FROM pdf_files LIKE 'cover_filename'");
        return $ready=(bool)$stmt->fetch();
    } catch (Throwable $e) { return $ready=false; }
}

function reviewers(): array
{
    static $items;
    if ($items !== null) return $items;

    $db = Database::connection();
    if ($db) {
        try {
            $coverColumns=pdf_cover_schema_ready($db)?'p.cover_filename,p.cover_position_x,p.cover_position_y,':'NULL AS cover_filename,50 AS cover_position_x,50 AS cover_position_y,';
            $upgraded=table_exists($db,'professions');
            $role=(user()['role']??'examinee')==='examinee'?'candidate':(user()['role']??'candidate');
            $visibility=$role==='admin'?'p.status<>"archived"':($role==='contributor'?'p.contributor_id=? AND p.status<>"archived"':'p.status="published"');
            $sql = 'SELECT p.id,p.title,p.description,p.pages,p.free_pages,p.access_level,p.status,p.created_at,'.($upgraded?'p.profession_id,p.subject_id,':'NULL AS profession_id,p.subject_id,').'
                    '.$coverColumns.'
                    '.($upgraded?'pr.name AS profession,COALESCE(s.subject_name,c.category_name) AS category,p.access_policy,p.price_centavos,p.subscription_included,p.owner_type,p.ownership_status,p.ownership_watermark,p.uploaded_by_user_id,p.pdf_version,COALESCE(rpf.verified_badge,"none") AS verified_badge,rpf.verified_rank,':'"Teacher Education" AS profession,c.category_name AS category,p.access_level AS access_policy,NULL AS price_centavos,1 AS subscription_included,"contributor" AS owner_type,"verified" AS ownership_status,NULL AS ownership_watermark,p.contributor_id AS uploaded_by_user_id,1 AS pdf_version,"none" AS verified_badge,NULL AS verified_rank,').'
                    COALESCE(s.subject_name,c.category_name) AS subject,
                    u.fullname AS contributor,p.contributor_id,COALESCE(rp.percentage,0) AS progress
                    FROM pdf_files p JOIN categories c ON c.id=p.category_id
                    JOIN users u ON u.id=p.contributor_id LEFT JOIN subjects s ON s.id=p.subject_id
                    '.($upgraded?'LEFT JOIN professions pr ON pr.id=p.profession_id LEFT JOIN role_profiles rpf ON rpf.user_id=p.contributor_id AND rpf.role="contributor" ':'').'
                    LEFT JOIN reading_progress rp ON rp.pdf_id=p.id AND rp.user_id=?
                    WHERE '.$visibility.' ORDER BY p.created_at DESC';
            $stmt = $db->prepare($sql);
            $params=[(int)user()['id']]; if($role==='contributor')$params[]=(int)user()['id'];
            $stmt->execute($params);
            $rows = $stmt->fetchAll();
            if ($rows) return $items = array_map(static function (array $row): array {
                $row['id']=(int)$row['id']; $row['pages']=(int)$row['pages']; $row['free_pages']=(int)$row['free_pages'];
                $row['progress']=(int)round((float)$row['progress']);
                return $row;
            }, $rows);
        } catch (Throwable $e) {
            // Keep the interface usable before the optional cover migration is applied.
        }
    }

    return $items = [];
}

function reviewer(int $id): array
{
    foreach (reviewers() as $item) {
        if ($item['id'] === $id) return $item;
    }
    http_response_code(404);exit('Reviewer not found.');
}

function reviewer_cover(array $reviewer, string $class = ''): string
{
    $title = e($reviewer['title'] ?? 'Reviewer');
    $category = e($reviewer['category'] ?? 'Reviewer');
    $tone = e($reviewer['tone'] ?? ['sun','ember','cream','sienna','brown','honey'][((int)($reviewer['id'] ?? 1)-1)%6]);
    $classes = trim('book-cover cover-'.$tone.' '.$class);
    $coverFilename=basename((string)($reviewer['cover_filename']??''));
    if ($coverFilename!==''&&is_file(REPASO_ROOT.'/uploads/covers/'.$coverFilename)) {
        $src = e(url('uploads/covers/'.$coverFilename));
        $x = max(0,min(100,(int)($reviewer['cover_position_x'] ?? 50)));
        $y = max(0,min(100,(int)($reviewer['cover_position_y'] ?? 50)));
        return '<div class="'.$classes.' has-image"><img src="'.$src.'" alt="Cover of '.$title.'" style="object-position:'.$x.'% '.$y.'%"></div>';
    }
    return '<div class="'.$classes.'" role="img" aria-label="Fallback cover for '.$title.'"><span class="cover-kicker">'.$category.'</span><span class="cover-title">'.$title.'</span><span class="cover-mark">'.icon('library',24).'<b>REPASO</b></span></div>';
}

function validate_cover_upload(?array $file, ?string &$error): ?string
{
    if (!$file || ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return null;
    if (($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) { $error='The cover image could not be uploaded.'; return null; }
    if (($file['size'] ?? 0) > 5*1024*1024) { $error='Cover images must be 5 MB or smaller.'; return null; }
    $allowed=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
    $mime=(new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    $size=@getimagesize($file['tmp_name']);
    if (!$size || !isset($allowed[$mime]) || $size[0] < 240 || $size[1] < 360 || $size[0] > 6000 || $size[1] > 9000) {
        $error='Use a valid JPG, PNG, or WebP image between 240×360 and 6000×9000 pixels.'; return null;
    }
    $directory=REPASO_ROOT.'/uploads/covers';
    if (!is_dir($directory)) @mkdir($directory,0775,true);
    $filename=bin2hex(random_bytes(16)).'.'.$allowed[$mime];
    if (!move_uploaded_file($file['tmp_name'],$directory.'/'.$filename)) { $error='The cover image could not be saved.'; return null; }
    return $filename;
}

function icon(string $name, int $size = 18): string
{
    $paths = [
        'home'=>'<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/><path d="M9 21v-7h6v7"/>',
        'library'=>'<path d="M4 4h6v16H4zM14 4h6v16h-6z"/><path d="M7 8h0M17 8h0"/>',
        'offline'=>'<path d="M12 3v12m0 0 4-4m-4 4-4-4"/><path d="M5 19h14"/>',
        'bookmark'=>'<path d="M6 3h12v18l-6-4-6 4z"/>',
        'notes'=>'<path d="M5 3h14v18H5z"/><path d="M8 8h8M8 12h8M8 16h5"/>',
        'chart'=>'<path d="M4 20V10m6 10V4m6 16v-7m5 7H2"/>',
        'settings'=>'<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1A1.7 1.7 0 0 0 4.6 15 1.7 1.7 0 0 0 3 14H2.8v-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1A1.7 1.7 0 0 0 9 4.6 1.7 1.7 0 0 0 10 3V2.8h4V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1z"/>',
        'search'=>'<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
        'bell'=>'<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/>',
        'play'=>'<path d="m8 5 11 7-11 7z"/>',
        'shield'=>'<path d="M12 3 4 6v5c0 5 3.4 8.6 8 10 4.6-1.4 8-5 8-10V6z"/><path d="m9 12 2 2 4-5"/>',
        'upload'=>'<path d="M12 16V4m0 0-4 4m4-4 4 4"/><path d="M4 20h16"/>',
        'users'=>'<circle cx="9" cy="8" r="4"/><path d="M2 21c0-4 3-7 7-7s7 3 7 7"/><path d="M16 5c3 0 5 2 5 5"/>',
        'menu'=>'<path d="M4 7h16M4 12h16M4 17h16"/>',
        'close'=>'<path d="m6 6 12 12M18 6 6 18"/>',
        'chevron'=>'<path d="m9 18 6-6-6-6"/>',
        'check'=>'<path d="m5 12 4 4L19 6"/>',
        'lock'=>'<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
    ];
    $body = $paths[$name] ?? $paths['check'];
    return '<svg width="'.$size.'" height="'.$size.'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'.$body.'</svg>';
}

function nav_items(): array
{
    $role = user()['role'] ?? 'examinee';
    if ($role === 'admin') {
        return [
            ['admin/dashboard.php','home','Dashboard'], ['admin/submit-pdf.php','upload','Submit PDF'], ['admin/published.php','library','Published catalog'], ['admin/manage-pdfs.php','shield','Manage PDFs'],
            ['admin/acquisitions.php','notes','PDF acquisitions'],
            ['admin/categories.php','bookmark','Catalog'], ['admin/applications.php','shield','Applications'], ['admin/recovery-requests.php','lock','Recovery requests'], ['admin/users.php','users','Users'],
            ['admin/ads.php','chart','Ads Management'], ['admin/system-monitoring.php','shield','System Monitoring'],
            ['admin/reports.php','notes','Reports'], ['admin/ownership-report.php','chart','Ownership finance'], ['profile.php','settings','Settings'],
        ];
    }
    if ($role === 'contributor') {
        return [
            ['contributor/dashboard.php','home','Dashboard'], ['contributor/upload.php','upload','Submit PDF'],
            ['contributor/reports.php','chart','Earnings & reports'], ['contributor/published.php','library','Published catalog'],
            ['profile.php','settings','Settings'],
        ];
    }
    return [
        ['dashboard.php','home','Home'], ['library.php','library','My Library'], ['offline.php','offline','Offline Shelf'],
        ['bookmarks.php','bookmark','Bookmarks'], ['notes.php','notes','Notes'], ['progress.php','chart','My Progress'],
        ['pricing.php','shield','Subscription'], ['payments.php','notes','Payment history'], ['profile.php','settings','Settings'],
    ];
}
