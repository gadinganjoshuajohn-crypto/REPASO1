<?php
declare(strict_types=1);

final class PdfWatermarker
{
    public static function create(string $source, string $destination, array $license, ?int $maxPages=null): string
    {
        $autoload = REPASO_ROOT . '/vendor/autoload.php';
        if (!is_file($autoload)) {
            throw new RuntimeException('Install Composer dependencies before generating downloadable watermarked PDFs.');
        }
        require_once $autoload;
        $pdf = new setasign\Fpdi\Fpdi();
        $count = $pdf->setSourceFile($source);if($maxPages!==null)$count=min($count,max(1,$maxPages));
        for ($page = 1; $page <= $count; $page++) {
            $template = $pdf->importPage($page);
            $size = $pdf->getTemplateSize($template);
            $pdf->AddPage($size['orientation'], [$size['width'], $size['height']]);
            $pdf->useTemplate($template);
            $pdf->SetTextColor(150,150,150);
            $pdf->SetFont('Helvetica','B',14);
            if(!empty($license['ownership'])){$pdf->SetXY(15,$size['height']/2-20);$pdf->Cell($size['width']-30,10,(string)$license['ownership'],0,0,'C');}
            $pdf->SetXY(15, $size['height']/2 - 8 + (($page % 3)-1)*22);
            $identity=trim((string)$license['name'].(!empty($license['email'])?' | '.$license['email']:''));
            $text = sprintf('REPASO | %s | %s | DO NOT DISTRIBUTE', $identity, $license['date']);
            $pdf->Cell($size['width']-30, 10, $text, 0, 0, 'C');
        }
        $pdf->Output('F', $destination);
        return $destination;
    }
}
