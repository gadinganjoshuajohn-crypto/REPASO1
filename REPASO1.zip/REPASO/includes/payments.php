<?php
declare(strict_types=1);

function paymongo_mode(): string { return getenv('REPASO_PAYMONGO_MODE')==='live'?'live':'test'; }
function demo_payments_enabled(): bool { return paymongo_mode()==='test'&&getenv('REPASO_DEMO_PAYMENTS')==='1'; }
function paymongo_secret_key(): string { return trim((string)getenv(paymongo_mode()==='live'?'REPASO_PAYMONGO_SECRET_KEY_LIVE':'REPASO_PAYMONGO_SECRET_KEY_TEST')); }
function paymongo_webhook_secret(bool $live): string { return trim((string)getenv($live?'REPASO_PAYMONGO_WEBHOOK_SECRET_LIVE':'REPASO_PAYMONGO_WEBHOOK_SECRET_TEST')); }

function paymongo_request(string $method,string $path,?array $body=null): array
{
    $key=paymongo_secret_key();if($key==='')throw new RuntimeException('PayMongo is not configured for '.paymongo_mode().' mode.');
    $path=ltrim($path,'/');if(!preg_match('#^v\d+/#',$path))$path='v1/'.$path;
    $ch=curl_init('https://api.paymongo.com/'.$path);$headers=['Accept: application/json','Content-Type: application/json','Authorization: Basic '.base64_encode($key.':')];
    curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_CUSTOMREQUEST=>$method,CURLOPT_HTTPHEADER=>$headers,CURLOPT_CONNECTTIMEOUT=>10,CURLOPT_TIMEOUT=>30]);
    if($body!==null)curl_setopt($ch,CURLOPT_POSTFIELDS,json_encode($body,JSON_UNESCAPED_SLASHES));
    $raw=curl_exec($ch);$code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$err=curl_error($ch);curl_close($ch);
    if($raw===false||$err)throw new RuntimeException('Payment provider connection failed.');
    $decoded=json_decode($raw,true);if($code<200||$code>=300)throw new RuntimeException($decoded['errors'][0]['detail']??'Payment provider rejected the request.');
    return is_array($decoded)?$decoded:[];
}

function paymongo_signature_valid(string $raw,string $header,bool $live): bool
{
    $parts=[];foreach(explode(',',$header) as $piece){[$k,$v]=array_pad(explode('=',trim($piece),2),2,'');$parts[$k]=$v;}
    $timestamp=$parts['t']??'';$provided=$parts[$live?'li':'te']??'';$secret=paymongo_webhook_secret($live);
    if(!ctype_digit($timestamp)||$provided===''||$secret===''||abs(time()-(int)$timestamp)>300)return false;
    return hash_equals(hash_hmac('sha256',$timestamp.'.'.$raw,$secret),$provided);
}

function paid_checkout_payment(array $sessionAttributes): array
{
    $paid=array_values(array_filter($sessionAttributes['payments']??[],static fn($p)=>(($p['attributes']['status']??'')==='paid')));
    if(count($paid)!==1)throw new RuntimeException('Checkout did not contain exactly one confirmed payment.');
    $intent=$sessionAttributes['payment_intent']??[];if($intent&&($intent['attributes']['status']??'')!=='succeeded')throw new RuntimeException('Checkout payment intent is not succeeded.');
    return $paid[0];
}

function confirm_checkout_session(PDO $db,int $orderId,string $checkoutId,array $sessionAttributes,bool $live): bool
{
    $payment=paid_checkout_payment($sessionAttributes);$attrs=$payment['attributes']??[];$attrs['livemode']=$live;
    return confirm_paid_order($db,$orderId,(string)($payment['id']??''),$attrs,$checkoutId,$sessionAttributes);
}

function confirm_paid_order(PDO $db,int $orderId,string $providerPaymentId,array $payload,?string $checkoutId=null,?array $sessionAttributes=null): bool
{
    $db->beginTransaction();try{
        $q=$db->prepare('SELECT o.*,p.duration_days plan_duration,pay.id payment_row_id,pay.provider_checkout_id FROM orders o LEFT JOIN candidate_plans p ON p.id=o.plan_id JOIN payments pay ON pay.order_id=o.id WHERE o.id=? FOR UPDATE');$q->execute([$orderId]);$order=$q->fetch();
        if(!$order)throw new RuntimeException('Order not found.');if($order['status']==='paid'){$db->commit();return false;}if($order['status']!=='pending')throw new RuntimeException('Order is not payable.');
        if($providerPaymentId===''||($payload['status']??'paid')!=='paid')throw new RuntimeException('Provider payment is not paid.');
        if($checkoutId!==null&&!hash_equals((string)$order['provider_checkout_id'],$checkoutId))throw new RuntimeException('Provider checkout did not match the order.');
        if($sessionAttributes!==null&&!hash_equals((string)$order['order_number'],(string)($sessionAttributes['reference_number']??'')))throw new RuntimeException('Provider reference did not match the order.');
        if((int)($payload['amount']??0)!==(int)$order['amount_centavos']||strtoupper((string)($payload['currency']??''))!==strtoupper((string)$order['currency']))throw new RuntimeException('Provider amount or currency did not match the order.');
        $env=!empty($payload['livemode'])?'live':'test';if($env!==$order['environment'])throw new RuntimeException('Provider environment did not match the order.');
        $u=$db->prepare('UPDATE orders SET status="paid",paid_at=UTC_TIMESTAMP() WHERE id=? AND status="pending"');$u->execute([$orderId]);if($u->rowCount()!==1)throw new RuntimeException('Order state changed while confirming payment.');
        $db->prepare('UPDATE payments SET provider_payment_id=?,provider_payment_intent_id=?,provider_reference=?,status="paid",confirmed_at=UTC_TIMESTAMP(),raw_payload=? WHERE id=?')->execute([$providerPaymentId,$payload['payment_intent_id']??null,$sessionAttributes['reference_number']??null,json_encode(['session'=>$sessionAttributes,'payment'=>$payload]),$order['payment_row_id']]);
        if($order['order_type']==='subscription'){
            $lock=$db->prepare('SELECT id FROM role_profiles WHERE id=? FOR UPDATE');$lock->execute([$order['candidate_profile_id']]);if(!$lock->fetchColumn())throw new RuntimeException('Candidate profile is unavailable.');
            $s=$db->prepare('SELECT MAX(end_date) FROM subscriptions WHERE candidate_profile_id=? AND status="active" AND end_date>UTC_TIMESTAMP() FOR UPDATE');$s->execute([$order['candidate_profile_id']]);$start=$s->fetchColumn()?:gmdate('Y-m-d H:i:s');
            $days=(int)($order['duration_days_snapshot']?:$order['plan_duration']);if($days<1)throw new RuntimeException('Order has no valid access duration snapshot.');$endAt=(new DateTimeImmutable($start,new DateTimeZone('UTC')))->modify('+'.$days.' days')->format('Y-m-d H:i:s');
            $db->prepare('INSERT INTO subscriptions(user_id,plan,start_date,end_date,status,candidate_profile_id,order_id,plan_id) SELECT user_id,"premium",?,? ,"active",?,?,? FROM role_profiles WHERE id=?')->execute([$start,$endAt,$order['candidate_profile_id'],$orderId,$order['plan_id'],$order['candidate_profile_id']]);
            $db->prepare('UPDATE users u JOIN role_profiles rp ON rp.user_id=u.id SET u.subscription="premium",u.subscription_end=GREATEST(COALESCE(u.subscription_end,UTC_TIMESTAMP()),?) WHERE rp.id=?')->execute([$endAt,$order['candidate_profile_id']]);
            if(table_exists($db,'platform_revenue_ledger'))$db->prepare('INSERT IGNORE INTO platform_revenue_ledger(order_id,pdf_id,entry_type,amount_centavos,environment,status,occurred_at) VALUES(?,NULL,"subscription",?, ?,"confirmed",UTC_TIMESTAMP())')->execute([$orderId,$order['amount_centavos'],$order['environment']]);
            if(table_exists($db,'subscription_share_allocations'))$db->prepare('INSERT IGNORE INTO subscription_share_allocations(order_id,status,reason) VALUES(?,"unallocated","Subscription-share allocation rule has not been approved; no contributor earnings were created.")')->execute([$orderId]);
        }else{
            $d=$db->prepare('SELECT individual_access_days,owner_type,ownership_status FROM pdf_files WHERE id=? FOR UPDATE');$d->execute([$order['pdf_id']]);$pdf=$d->fetch();$days=max(1,(int)($pdf['individual_access_days']??0));
            $db->prepare('INSERT INTO pdf_entitlements(candidate_profile_id,pdf_id,order_id,source,starts_at,expires_at) VALUES(?,?,?,"purchase",UTC_TIMESTAMP(),DATE_ADD(UTC_TIMESTAMP(),INTERVAL ? DAY))')->execute([$order['candidate_profile_id'],$order['pdf_id'],$orderId,$days]);
            if(($pdf['owner_type']??'')==='repaso'&&($pdf['ownership_status']??'')==='verified'){
                if(table_exists($db,'platform_revenue_ledger'))$db->prepare('INSERT IGNORE INTO platform_revenue_ledger(order_id,pdf_id,entry_type,amount_centavos,environment,status,occurred_at) VALUES(?,?,"repaso_pdf_sale",?, ?,"confirmed",UTC_TIMESTAMP())')->execute([$orderId,$order['pdf_id'],$order['amount_centavos'],$order['environment']]);
            }else{
                $a=$db->prepare('SELECT ca.*,rp.id contributor_profile_id FROM contributor_agreements ca JOIN pdf_files f ON f.id=ca.pdf_id JOIN role_profiles rp ON rp.user_id=f.contributor_id AND rp.role="contributor" WHERE ca.pdf_id=? AND ca.model="commission" AND ca.accepted_at IS NOT NULL AND ca.effective_at<=UTC_TIMESTAMP() ORDER BY ca.effective_at DESC LIMIT 1');$a->execute([$order['pdf_id']]);$agreement=$a->fetch();
                if($agreement){$bps=(int)$agreement['commission_basis_points'];$contributor=(int)round((int)$order['amount_centavos']*$bps/10000);$platform=(int)$order['amount_centavos']-$contributor;$db->prepare('INSERT INTO earnings_ledger(contributor_profile_id,pdf_id,order_id,agreement_id,entry_type,gross_centavos,contributor_centavos,platform_centavos,status,rate_snapshot,occurred_at) VALUES(?,?,?,? ,"sale",?,?,?,"pending",?,UTC_TIMESTAMP())')->execute([$agreement['contributor_profile_id'],$order['pdf_id'],$orderId,$agreement['id'],$order['amount_centavos'],$contributor,$platform,json_encode(['commission_basis_points'=>$bps,'agreement_id'=>(int)$agreement['id']])]);}
            }
        }
        $db->commit();return true;
    }catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}
}

function apply_confirmed_refund(PDO $db,string $providerRefundId,string $providerPaymentId,array $attrs,bool $live): bool
{
    if(($attrs['status']??'')!=='succeeded')return false;$db->beginTransaction();try{
        $q=$db->prepare('SELECT p.id payment_id,p.order_id,p.amount_centavos,o.environment,o.order_type,o.candidate_profile_id FROM payments p JOIN orders o ON o.id=p.order_id WHERE p.provider_payment_id=? FOR UPDATE');$q->execute([$providerPaymentId]);$paid=$q->fetch();if(!$paid)throw new RuntimeException('No payment matched the refund.');if(($live?'live':'test')!==$paid['environment'])throw new RuntimeException('Refund environment did not match the order.');
        $amount=(int)($attrs['amount']??0);if($amount<1||$amount>(int)$paid['amount_centavos'])throw new RuntimeException('Refund amount is invalid.');$r=$db->prepare('INSERT IGNORE INTO refunds(payment_id,provider_refund_id,order_id,amount_centavos,reason,status,confirmed_at) VALUES(?,?,?,?,?,"confirmed",UTC_TIMESTAMP())');$r->execute([$paid['payment_id'],$providerRefundId,$paid['order_id'],$amount,(string)($attrs['reason']??'Provider-confirmed refund')]);if($r->rowCount()===0){$db->commit();return false;}
        if(table_exists($db,'platform_revenue_ledger'))$db->prepare('INSERT INTO platform_revenue_ledger(order_id,pdf_id,entry_type,amount_centavos,environment,status,occurred_at) SELECT id,pdf_id,"refund",-?,environment,"confirmed",UTC_TIMESTAMP() FROM orders WHERE id=? ON DUPLICATE KEY UPDATE platform_revenue_ledger.amount_centavos=platform_revenue_ledger.amount_centavos+VALUES(amount_centavos),platform_revenue_ledger.occurred_at=VALUES(occurred_at)')->execute([$amount,$paid['order_id']]);
        $sale=$db->prepare('SELECT contributor_profile_id,pdf_id,agreement_id,gross_centavos,contributor_centavos,platform_centavos FROM earnings_ledger WHERE order_id=? AND entry_type="sale" LIMIT 1');$sale->execute([$paid['order_id']]);if($entry=$sale->fetch()){$ratio=$amount/max(1,(int)$paid['amount_centavos']);$gross=-$amount;$contributor=-(int)round((int)$entry['contributor_centavos']*$ratio);$platform=$gross-$contributor;$db->prepare('INSERT INTO earnings_ledger(contributor_profile_id,pdf_id,order_id,agreement_id,entry_type,gross_centavos,contributor_centavos,platform_centavos,status,rate_snapshot,occurred_at) VALUES(?,?,?,? ,"refund",?,?,?,"pending",?,UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE gross_centavos=gross_centavos+VALUES(gross_centavos),contributor_centavos=contributor_centavos+VALUES(contributor_centavos),platform_centavos=platform_centavos+VALUES(platform_centavos),occurred_at=VALUES(occurred_at)')->execute([$entry['contributor_profile_id'],$entry['pdf_id'],$paid['order_id'],$entry['agreement_id'],$gross,$contributor,$platform,json_encode(['provider_refund_id'=>$providerRefundId])]);}
        if($amount===(int)$paid['amount_centavos']){$db->prepare('UPDATE payments SET status="refunded",raw_payload=? WHERE id=?')->execute([json_encode($attrs),$paid['payment_id']]);$db->prepare('UPDATE orders SET status="refunded" WHERE id=?')->execute([$paid['order_id']]);$db->prepare('UPDATE pdf_entitlements SET revoked_at=UTC_TIMESTAMP() WHERE order_id=?')->execute([$paid['order_id']]);$db->prepare('UPDATE subscriptions SET status="cancelled" WHERE order_id=?')->execute([$paid['order_id']]);$db->prepare('UPDATE earnings_ledger SET status="reversed" WHERE order_id=?')->execute([$paid['order_id']]);if(table_exists($db,'platform_revenue_ledger'))$db->prepare('UPDATE platform_revenue_ledger SET status="reversed" WHERE order_id=?')->execute([$paid['order_id']]);if(table_exists($db,'subscription_share_allocations'))$db->prepare('UPDATE subscription_share_allocations SET status="reversed" WHERE order_id=?')->execute([$paid['order_id']]);
            if($paid['order_type']==='subscription'){
                $lock=$db->prepare('SELECT id FROM role_profiles WHERE id=? FOR UPDATE');$lock->execute([$paid['candidate_profile_id']]);$remaining=$db->prepare('SELECT s.id,COALESCE(o.duration_days_snapshot,cp.duration_days) duration_days FROM subscriptions s JOIN orders o ON o.id=s.order_id LEFT JOIN candidate_plans cp ON cp.id=o.plan_id WHERE s.candidate_profile_id=? AND s.status="active" AND o.status="paid" ORDER BY o.paid_at,o.id FOR UPDATE');$remaining->execute([$paid['candidate_profile_id']]);$cursor=new DateTimeImmutable('now',new DateTimeZone('UTC'));$lastEnd=null;foreach($remaining as $grant){$start=$cursor->format('Y-m-d H:i:s');$cursor=$cursor->modify('+'.max(1,(int)$grant['duration_days']).' days');$lastEnd=$cursor->format('Y-m-d H:i:s');$db->prepare('UPDATE subscriptions SET start_date=?,end_date=? WHERE id=?')->execute([$start,$lastEnd,$grant['id']]);}$db->prepare('UPDATE users u JOIN role_profiles rp ON rp.user_id=u.id SET u.subscription=?,u.subscription_end=? WHERE rp.id=?')->execute([$lastEnd?'premium':'free',$lastEnd,$paid['candidate_profile_id']]);
            }
        }
        $db->commit();return true;
    }catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}
}
