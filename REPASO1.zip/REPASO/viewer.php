<?php
require_once __DIR__.'/includes/bootstrap.php';
require_once __DIR__.'/includes/layout.php';
require_login();
$readerRole=(user()['role']??'examinee')==='examinee'?'candidate':(user()['role']??'candidate');
$candidateTools=$readerRole==='candidate';
$r=reviewer((int)($_GET['id']??1));
$db=Database::connection();
[$entitled,$basis]=$db?can_access_pdf($db,$r,false):[false,'unavailable'];
if(!$entitled){http_response_code(403);exit('This reviewer requires an active entitlement.');}
$preview=$basis==='preview';
$repasoOwned=pdf_is_repaso_owned($r);$adminOwnRepaso=$readerRole==='admin'&&$repasoOwned&&(int)($r['uploaded_by_user_id']??0)===(int)user()['id'];$protectionName=$adminOwnRepaso?'REPASO OWNED':user()['fullname'];$protectionEmail=$adminOwnRepaso?'':user()['email'];
$pages=max(1,(int)$r['pages']);
$limit=$preview?max(1,min($pages,(int)$r['free_pages'])):$pages;
$page=max(1,min((int)($_GET['page']??1),$limit));
if($db)record_usage($db,(int)$r['id'],$preview?'preview':'reader_session',in_array($basis,['individual','subscription'],true));
$streamUrl=url('pdf/stream.php?id='.(int)$r['id']);
?><!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=e($r['title'])?> · REPASO Reader</title><link rel="stylesheet" href="<?=e(asset('css/app.css'))?>"></head>
<body><div class="viewer-shell">
<header class="viewer-header"><a class="brand" href="<?=e(url('library.php'))?>"><img src="<?=e(asset('images/logo.jpg'))?>" alt="REPASO"><span>REPASO</span></a><div class="viewer-title"><strong><?=e($r['title'])?></strong><span><?=e($r['subject'])?><?=$repasoOwned?' · REPASO OWNED':''?></span></div><div class="viewer-controls"><button class="viewer-control" data-prev aria-label="Previous page">‹</button><label class="viewer-control"><input data-page-input value="<?=$page?>" inputmode="numeric" min="1" max="<?=$limit?>" aria-label="Current page"> / <?=$pages?></label><button class="viewer-control" data-next aria-label="Next page">›</button><button class="viewer-control zoom-control" data-fit-width>Fit width</button><button class="viewer-control" data-tools-toggle aria-label="Reader tools"><?=icon('menu')?></button></div></header>
<div class="viewer-body">
<aside class="thumbs" data-thumbnail-list aria-label="PDF page thumbnails"><div class="reader-loading compact"><span></span><p>Preparing pages…</p></div></aside>
<main class="document-stage actual-pdf-stage" data-pdf-scroll><div class="reader-loading" data-reader-loading><span></span><strong>Opening your reviewer</strong><p>The actual PDF pages and thumbnails are being prepared.</p></div><div class="pdf-document" data-pdf-document aria-label="<?=e($r['title'])?> PDF pages"></div><div class="viewer-watermark" aria-hidden="true"><?php if($repasoOwned):?><span>REPASO OWNED</span><?php endif;?><span>REPASO · <?=e($protectionName)?> · DO NOT DISTRIBUTE</span><?php if($protectionEmail!==''):?><span>REPASO · <?=e($protectionEmail)?></span><?php endif;?></div></main>
<aside class="viewer-tools" id="viewerTools"><div class="reader-file-status"><span class="status ok">Actual uploaded PDF</span><p class="meta"><?=e(ucwords(str_replace('_',' ',$basis)))?> access</p></div><?php if($candidateTools):?><div class="tool-list"><button class="tool-button" data-note><?=icon('notes')?>Add note</button><button class="tool-button" data-bookmark><?=icon('bookmark')?>Bookmark page</button><a class="tool-button" href="<?=e(url('notes.php'))?>"><?=icon('notes')?>View notes</a><a class="tool-button" href="<?=e(url('bookmarks.php'))?>"><?=icon('bookmark')?>View bookmarks</a></div><?php endif;?><div class="section-heading"><h3>Progress</h3></div><div class="progress-bar"><span data-reader-progress style="width:<?=round($page/$pages*100)?>%"></span></div><p class="meta"><span data-current-page><?=$page?></span> / <?=$pages?> pages</p><?php if($preview):?><div class="preview-limit"><div class="lock"><?=icon('lock',24)?></div><h3>Preview access</h3><p class="meta">This account can open the first <?=$limit?> pages of this reviewer.</p><a class="button gold block" href="<?=e(url('pricing.php'))?>">View plans</a></div><?php endif;?></aside>
</div></div>
<?php if($candidateTools):?><div class="reader-modal" data-note-modal hidden><section class="reader-modal-card" role="dialog" aria-modal="true" aria-labelledby="note-title"><button class="reader-modal-close" data-note-close aria-label="Close">×</button><div class="eyebrow">Study note</div><h2 id="note-title">Add a note to page <span data-note-page><?=$page?></span></h2><p class="muted">Keep a concise reminder connected to this exact page.</p><textarea data-note-text rows="6" maxlength="4000" placeholder="Write your note here…"></textarea><div class="reader-modal-actions"><button class="button ghost" data-note-close>Cancel</button><button class="button gold" data-note-save>Save note</button></div><p class="reader-form-status" data-note-status aria-live="polite"></p></section></div><?php endif;?>
<div class="reader-toast" data-reader-toast role="status" aria-live="polite" hidden></div>
<script>window.READER={page:<?=$page?>,pages:<?=$pages?>,limit:<?=$limit?>,id:<?=(int)$r['id']?>,stream:<?=json_encode($streamUrl)?>,track:<?=$candidateTools?'true':'false'?>,base:<?=json_encode(url(''))?>,csrf:<?=json_encode($_SESSION['csrf'])?>,pdfjs:<?=json_encode(asset('vendor/pdfjs/pdf.min.mjs'))?>,worker:<?=json_encode(asset('vendor/pdfjs/pdf.worker.min.mjs'))?>,cmaps:<?=json_encode(asset('vendor/pdfjs/cmaps/'))?>,fonts:<?=json_encode(asset('vendor/pdfjs/standard_fonts/'))?>};</script>
<script type="module" src="<?=e(asset('js/viewer.js'))?>"></script></body></html>
