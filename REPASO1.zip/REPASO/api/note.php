<?php
require_once dirname(__DIR__).'/includes/bootstrap.php';
require_approved_profile('candidate');
if($_SERVER['REQUEST_METHOD']!=='POST')json_response(['error'=>'Method not allowed'],405);
verify_csrf();
$isJson=str_contains(strtolower((string)($_SERVER['CONTENT_TYPE']??'')),'application/json');
$input=$isJson?json_input():$_POST;
$pdf=(int)($input['pdf_id']??0);
$page=(int)($input['page']??0);
$note=trim((string)($input['note']??''));
if($pdf<1||$page<1||$note===''){
    if($isJson)json_response(['error'=>'A PDF, page, and note are required.'],422);
    flash('error','A PDF, page, and note are required.');redirect('notes.php');
}
if((function_exists('mb_strlen')?mb_strlen($note,'UTF-8'):strlen($note))>4000){
    if($isJson)json_response(['error'=>'Notes may contain up to 4,000 characters.'],422);
    flash('error','Notes may contain up to 4,000 characters.');redirect('notes.php');
}
$db=Database::connection();
if(!$db){if($isJson)json_response(['error'=>'The database is unavailable.'],503);redirect('notes.php');}
$record=reviewer($pdf);
[$allowed]=can_access_pdf($db,$record,false);
if(!$allowed)json_response(['error'=>'You cannot add a note to this reviewer.'],403);
$stmt=$db->prepare('INSERT INTO notes(user_id,pdf_id,page,note,created_at) VALUES(?,?,?,?,NOW())');
$stmt->execute([user()['id'],$pdf,$page,$note]);
if($isJson)json_response(['ok'=>true,'page'=>$page]);
flash('success','Note saved.');redirect('notes.php');
