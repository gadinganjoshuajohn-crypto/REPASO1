<?php
require_once dirname(__DIR__).'/includes/bootstrap.php';require_login();require_approved_profile('candidate');http_response_code(410);exit('Manual reference activation has been retired. Use the server-created GCash checkout flow.');
