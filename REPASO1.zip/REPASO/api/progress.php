<?php
require_once dirname(__DIR__).'/includes/bootstrap.php';
require_approved_profile('candidate');
if($_SERVER['REQUEST_METHOD']!=='POST')json_response(['error'=>'Method not allowed'],405);verify_csrf();$in=json_input();$pdf=(int)($in['pdf_id']??0);$page=max(1,(int)($in['page']??1));$pages=max(1,(int)($in['pages']??1));if($pdf<1)json_response(['error'=>'Invalid reviewer'],422);$db=Database::connection();if($db){$pct=min(100,round($page/$pages*100,2));$stmt=$db->prepare('INSERT INTO reading_progress(user_id,pdf_id,current_page,percentage,last_opened_at) VALUES(?,?,?,?,NOW()) ON DUPLICATE KEY UPDATE current_page=VALUES(current_page),percentage=VALUES(percentage),last_opened_at=NOW()');$stmt->execute([user()['id'],$pdf,$page,$pct]);}json_response(['ok'=>true,'page'=>$page]);
