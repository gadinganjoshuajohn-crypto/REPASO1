<?php
require_once dirname(__DIR__).'/includes/bootstrap.php';
require_approved_profile('candidate');
if($_SERVER['REQUEST_METHOD']!=='POST')json_response(['error'=>'Method not allowed'],405);verify_csrf();$in=json_input();$pdf=(int)($in['pdf_id']??0);$page=(int)($in['page']??0);if($pdf<1||$page<1)json_response(['error'=>'Invalid bookmark'],422);$db=Database::connection();if($db){$stmt=$db->prepare('INSERT IGNORE INTO bookmarks(user_id,pdf_id,page_number,created_at) VALUES(?,?,?,NOW())');$stmt->execute([user()['id'],$pdf,$page]);}json_response(['ok'=>true]);
