<?php
$newPassword = '12345678';
echo password_hash($newPassword, PASSWORD_BCRYPT);
?>