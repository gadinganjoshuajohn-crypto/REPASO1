<?php
require_once dirname(__DIR__).'/includes/bootstrap.php';require_login();

function stream_pdf_file(string $path,string $filename,bool $download=false): never
{
    $size=filesize($path);$start=0;$end=$size-1;$status=200;
    if(!$download&&isset($_SERVER['HTTP_RANGE'])&&preg_match('/bytes=(\d*)-(\d*)/',$_SERVER['HTTP_RANGE'],$m)){
        if($m[1]!==''&&$m[2]!==''){$start=(int)$m[1];$end=min($end,(int)$m[2]);}
        elseif($m[1]!=='')$start=(int)$m[1];
        elseif($m[2]!=='')$start=max(0,$size-(int)$m[2]);
        if($start>$end||$start>=$size){header('Content-Range: bytes */'.$size);http_response_code(416);exit;}$status=206;
    }
    http_response_code($status);header('Content-Type: application/pdf');header('Accept-Ranges: bytes');header('Cache-Control: private, no-store, max-age=0');header('Content-Disposition: '.($download?'attachment':'inline').'; filename="'.$filename.'"');header('Content-Length: '.($end-$start+1));if($status===206)header("Content-Range: bytes $start-$end/$size");
    $handle=fopen($path,'rb');if(!$handle){http_response_code(500);exit('PDF file could not be opened.');}fseek($handle,$start);$remaining=$end-$start+1;while($remaining>0&&!feof($handle)){$chunk=fread($handle,min(8192,$remaining));if($chunk===false)break;echo $chunk;$remaining-=strlen($chunk);if(connection_aborted())break;}fclose($handle);exit;
}

$id=(int)($_GET['id']??0);$download=!empty($_GET['download']);$db=Database::connection();if(!$db){http_response_code(503);exit('Database connection is required for secure PDF streaming.');}
$role=(user()['role']??'examinee')==='examinee'?'candidate':(user()['role']??'candidate');$sql=$role==='admin'?'SELECT * FROM pdf_files WHERE id=? LIMIT 1':($role==='contributor'?'SELECT * FROM pdf_files WHERE id=? AND contributor_id=? LIMIT 1':'SELECT * FROM pdf_files WHERE id=? AND status="published" LIMIT 1');$stmt=$db->prepare($sql);$stmt->execute($role==='contributor'?[$id,user()['id']]:[$id]);$record=$stmt->fetch();if(!$record){http_response_code(404);exit('Reviewer not found.');}
[$allowed,$basis]=can_access_pdf($db,$record,$download);if(!$allowed){http_response_code(403);exit('An approved profile and valid PDF entitlement are required.');}
$source=REPASO_ROOT.'/uploads/pdfs/'.basename((string)$record['filename']);if(!is_file($source)){http_response_code(404);exit('The uploaded PDF file is unavailable.');}$safeName=(preg_replace('/[^a-z0-9-]+/i','-',strtolower((string)$record['title']))?:'repaso-reviewer').'.pdf';$served=$source;$watermarked=false;

if($download||$basis==='preview'){
    require_once REPASO_ROOT.'/includes/PdfWatermarker.php';$maxPages=$basis==='preview'?max(1,(int)$record['free_pages']):null;$repasoOwned=pdf_is_repaso_owned($record);$adminOwnRepaso=$role==='admin'&&$repasoOwned&&(int)($record['uploaded_by_user_id']??0)===(int)user()['id'];$license=['name'=>$adminOwnRepaso?'REPASO OWNED':user()['fullname'],'email'=>$adminOwnRepaso?'':user()['email'],'date'=>date('F j, Y').' · '.strtoupper($basis),'ownership'=>$repasoOwned?'REPASO OWNED':''];$cacheVersion=(int)($record['pdf_version']??1).'|'.(string)($record['ownership_watermark']??'');$target=REPASO_ROOT.'/storage/watermarked/'.hash('sha256',user()['id'].'|'.$id.'|'.$role.'|'.$basis.'|'.($maxPages??'all').'|'.$cacheVersion.'|'.filemtime($source).'|'.date('Y-m-d-H')).'.pdf';
    try{if(!is_file($target))PdfWatermarker::create($source,$target,$license,$maxPages);$served=$target;$watermarked=true;}catch(Throwable $e){error_log('[REPASO] PDF watermark generation failed: '.$e->getMessage());http_response_code(503);header('Content-Type: text/plain; charset=utf-8');exit($basis==='preview'?'Secure PDF preview is temporarily unavailable. Install the project Composer dependencies and try again.':'The protected download could not be generated. Install the project Composer dependencies and try again.');}
}

if($watermarked&&table_exists($db,'watermark_logs')){$log=$db->prepare('INSERT INTO watermark_logs(user_id,pdf_id,date_accessed,ip_address,output_file) VALUES(?,?,UTC_TIMESTAMP(),?,?)');$log->execute([user()['id'],$id,$_SERVER['REMOTE_ADDR']??'',basename($served)]);}
if($download)record_usage($db,$id,'file_delivery',in_array($basis,['individual','subscription'],true));
if($role==='admin'&&empty($_SERVER['HTTP_RANGE'])&&table_exists($db,'admin_audit_log')){$a=$db->prepare('INSERT INTO admin_audit_log(admin_user_id,action,target_type,target_id,details,ip_address) VALUES(?,"pdf_preview","pdf",?,?,?)');$a->execute([user()['id'],(string)$id,json_encode(['basis'=>$basis,'source'=>'inline_stream']),$_SERVER['REMOTE_ADDR']??null]);}
stream_pdf_file($served,$safeName,$download);
