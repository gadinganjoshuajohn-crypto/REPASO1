<?php
require_once __DIR__.'/includes/bootstrap.php';
require_once __DIR__.'/includes/layout.php';
require_approved_profile('candidate');
$db=Database::connection();
$cover=pdf_cover_schema_ready($db)?'p.cover_filename,p.cover_position_x,p.cover_position_y,':'NULL cover_filename,50 cover_position_x,50 cover_position_y,';
$q=$db->prepare('SELECT n.page,n.note,n.updated_at,p.id,p.title,'.$cover.'c.category_name category,COALESCE(s.subject_name,c.category_name) subject FROM notes n JOIN pdf_files p ON p.id=n.pdf_id JOIN categories c ON c.id=p.category_id LEFT JOIN subjects s ON s.id=p.subject_id WHERE n.user_id=? ORDER BY n.updated_at DESC');
$q->execute([user()['id']]);$rows=$q->fetchAll();
page_start('Notes');
?>
<div class="section-heading saved-page-heading"><div><div class="eyebrow">Study notes</div><h1>Notes</h1><p class="muted">Your page-specific thoughts, organized for quick review.</p></div><a class="button ghost" href="<?=e(url('library.php'))?>">Browse library</a></div>
<?php if($rows):?><section class="saved-page-grid notes-grid"><?php foreach($rows as $r):?><article class="saved-page-card note-card"><?=reviewer_cover($r,'saved-page-cover')?><div class="saved-page-copy"><div class="saved-page-top"><span class="page-chip"><?=icon('notes',15)?> Page <?=(int)$r['page']?></span><span class="meta"><?=e(manila_time($r['updated_at']))?></span></div><h2><?=e($r['title'])?></h2><blockquote><?=nl2br(e($r['note']))?></blockquote><a class="button navy small" href="viewer.php?id=<?=(int)$r['id']?>&page=<?=(int)$r['page']?>">Open page <?=icon('chevron',15)?></a></div></article><?php endforeach;?></section><?php else:?><section class="empty-state saved-empty"><?=icon('notes',34)?><h2>No notes yet</h2><p>Use <strong>Add note</strong> in the reader to capture an idea without leaving the PDF.</p><a class="button gold" href="library.php">Open a reviewer</a></section><?php endif;?>
<?php page_end();
