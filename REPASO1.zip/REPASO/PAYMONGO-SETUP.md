# PayMongo GCash setup

REPASO uses PayMongo Hosted Checkout, fixed-duration orders, manual renewal, and verified server-side fulfillment. The browser return page only displays the database order status; it never grants access.

## Presentation/demo mode without GCash

Set `REPASO_PAYMONGO_MODE=test` and `REPASO_DEMO_PAYMENTS=1`. Candidate checkout opens REPASO's clearly labelled simulator where the presenter can choose success, pending, failure, or cancellation. A simulated success grants test-only access through the same idempotent order-fulfillment code, but creates no PayMongo transaction and collects no money. Demo orders remain in the `test` environment and are excluded from live revenue.

Demo payments are automatically disabled whenever `REPASO_PAYMONGO_MODE=live`. Use `REPASO_DEMO_PAYMENTS=0` for real PayMongo testing or production.

## Test mode

1. Apply all database migrations, ending with `database/migrations/2026_11_09_ownership_payments_catalog.sql`.
2. Set `REPASO_APP_URL` to the public HTTPS base URL. PayMongo webhooks require a public HTTPS domain, not an IP address.
3. Set `REPASO_PAYMONGO_MODE=test`, `REPASO_DEMO_PAYMENTS=0`, `REPASO_PAYMONGO_SECRET_KEY_TEST=sk_test_...`, and `REPASO_PAYMONGO_WEBHOOK_SECRET_TEST=whsk_...`.
4. In PayMongo Dashboard → Developers/Webhooks, create a test endpoint at `https://YOUR-DOMAIN/api/paymongo-webhook.php` and subscribe to `checkout_session.payment.paid`, `payment.failed`, and `payment.refund.updated`.
5. Save the endpoint-specific signing secret. It is different from the API secret key.
6. Configure active rows in `candidate_plans` and optional current rows in `promotions`. Checkout snapshots the agreed plan name, description, duration, price, currency, and environment on the order.
7. Schedule `cron/payment_reconciliation.php` every 15 minutes under the same environment configuration.

Run the test matrix in `VERIFICATION-REPORT.md`. Test and live orders remain separated by `orders.environment`; admin revenue reports count only live confirmed revenue.

## Live mode

1. Complete PayMongo KYC and merchant activation, then confirm that GCash is enabled for the live account. This approval is external to REPASO and may remain pending.
2. Add a separate live webhook endpoint (or the same URL registered in live mode) and save its live signing secret as `REPASO_PAYMONGO_WEBHOOK_SECRET_LIVE`.
3. Set `REPASO_PAYMONGO_SECRET_KEY_LIVE=sk_live_...`; never place either secret in PHP, JavaScript, a repository, or a browser response.
4. After test evidence is accepted, switch only the production environment to `REPASO_PAYMONGO_MODE=live` and perform a low-value controlled transaction and refund.
5. Monitor `payment_webhook_events`, cron logs, orders, refunds, and the ownership finance report. A failed event remains retryable; processed events are idempotent.

Implementation references (current official documentation):

- Hosted Checkout quick start: https://docs.paymongo.com/docs/payment-channels-hosted-checkout-quick-start
- Checkout Session resource: https://docs.paymongo.com/reference/checkout-session-resource
- Webhook signing and endpoint setup: https://docs.paymongo.com/docs/developer-tools-webhook-setup-management
- Webhook event payloads: https://docs.paymongo.com/docs/developer-tools-webhooks-events

