# REPASO

REPASO is a responsive PHP 8 and MariaDB reviewer platform for board examination candidates, content contributors, and administrators. The application uses a minimal burgundy, parchment, cream, and mist-blue visual system and includes a protected reader, freemium access controls, PWA support, progress tools, role-based portals, account recovery, and scheduled maintenance scripts.

REPASO checks eligibility to use this platform. It does not conduct examinations, automate scoring, or determine official eligibility to take a licensure examination.

## Requirements

- XAMPP with PHP 8+, Apache, and MariaDB/MySQL
- PHP extensions: `pdo_mysql`, `fileinfo`, `mbstring`
- Bundled PHP dependencies for PDF watermarking and SMTP notifications (Composer is needed only when upgrading them)
- HTTPS in production for full PWA and secure-cookie behavior

## Setup on XAMPP

1. Copy the `REPASO` folder to `C:\xampp\htdocs\REPASO`.
2. Start Apache and MySQL from the XAMPP control panel.
3. For a new installation, import `database/repaso_db.sql`, then apply `database/migrations/2026_10_16_platform_upgrade.sql`, `database/migrations/2026_10_16_role_application_policies.sql`, and `database/migrations/2026_11_03_account_recovery_and_profiles.sql` in that order. The base schema already includes reviewer-cover columns, so a fresh installation must skip the older cover migration.
4. The required production dependencies are included under `vendor`. Run `composer install --no-dev --optimize-autoloader` only when updating packages from `composer.lock`.
5. Configure the environment variables shown in `.env.example` in Apache or Windows.
6. Ensure `uploads/pdfs`, `uploads/profiles`, `storage/evidence`, `storage/watermarked`, `storage/backups`, and `storage/logs` are writable by Apache.
7. Open `http://localhost/REPASO/`.

For an existing REPASO database:

1. Back up the database and the `uploads` and `storage` folders.
2. Apply the cover migration if it has not already been applied.
3. Apply `database/migrations/2026_10_16_platform_upgrade.sql` once.
4. Apply `database/migrations/2026_10_16_role_application_policies.sql` once.
5. Apply `database/migrations/2026_11_03_account_recovery_and_profiles.sql` once.
6. Confirm that legacy PDFs now belong to Teacher Education and retain their original contributor, filename, and record ID.
7. Review legacy candidate and contributor profiles marked `legacy_review_required=1`.
8. Ensure `storage/evidence` is writable by PHP but not web-accessible. Recovery identity documents share this private store.

The rollback script is `database/migrations/2026_10_16_platform_upgrade_rollback.sql`. It is destructive for all new application, profile, payment, event, and ledger records; use it only after a tested backup. It deliberately does not delete users or PDFs.

## GCash via PayMongo

REPASO creates Checkout Sessions with the amount, currency, plan, promotion, and candidate profile chosen on the server. The checkout offers GCash only. A return-page visit never activates access. Activation occurs only after an authenticated webhook or server-side reconciliation confirms the matching amount, PHP currency, environment, and order.

Set these server environment variables:

- `REPASO_PAYMONGO_MODE=test` or `live`
- `REPASO_PAYMONGO_SECRET_KEY_TEST`
- `REPASO_PAYMONGO_SECRET_KEY_LIVE`
- `REPASO_PAYMONGO_WEBHOOK_SECRET_TEST`
- `REPASO_PAYMONGO_WEBHOOK_SECRET_LIVE`
- `REPASO_APP_URL`

Register one PayMongo webhook endpoint at `https://YOUR_HOST/REPASO/api/paymongo-webhook.php` for paid checkout/payment and refund events. Keep test and live webhook secrets separate. Add `cron/payment_reconciliation.php` every 15 minutes to recover missed notifications. The handler stores event IDs and makes order fulfillment idempotent, so retries do not extend a subscription twice.

GCash live availability, merchant approval, API keys, webhook registration, and the configured refund policy require external activation. Test-mode orders remain labeled test and are excluded from live collection reports. REPASO never collects GCash PINs or OTPs.

## Administration and configuration

- Configure professions and subjects under Admin → Catalog. Entries with linked PDFs are retained and can be deactivated.
- Review eligibility evidence only through Admin → Applications. Evidence is stored under `storage/evidence`, never `uploads`.
- Review manual ownership evidence and issue 24-hour, single-use codes through Admin → Recovery requests. Never send a code before verifying the submitted ID/document and incident report.
- Configure candidate and contributor evidence requirements, instructions, size limits, and retention periods under Admin → Applications.
- Verify PDF distribution rights separately from contributor qualifications before publishing.
- Configure candidate plans, PDF access policies, access durations, promotions, contributor agreements, commission rates, evidence retention, and refund policy in the database/admin workflow before production launch.
- Subscription revenue sharing creates no earnings unless an explicit accepted agreement and allocation rule exists. Individual-sale rates are snapshotted in the ledger.

## Verification

See `PAYMONGO-SETUP.md` for current Hosted Checkout/webhook configuration and `VERIFICATION-REPORT.md` for the implemented test boundary and remaining integration test matrix.

This packaged demo build enables the clearly labelled, test-only GCash simulator through `.htaccess`. It never contacts GCash or PayMongo and never counts as live revenue. Remove the demo `SetEnv` lines and follow `PAYMONGO-SETUP.md` before enabling real payments.

Run `php tests/security_smoke.php` and lint all PHP files before deployment. Then verify with test accounts:

1. Pending applications cannot sign in; approval creates only the requested role profile.
2. A linked profile switch succeeds only for another approved profile owned by the same user.
3. A contributor cannot edit or stream another contributor's PDF.
4. A candidate cannot stream a premium PDF without an active subscription or individual entitlement.
5. A browser redirect or edited query parameter does not activate access.
6. A valid paid webhook activates once; replaying the same event leaves dates and ledger entries unchanged.
7. Early renewal extends the active expiry; an expired plan starts at confirmation time.
8. A confirmed refund revokes order-derived access and reverses the related earnings entry.
9. Test transactions do not appear in live collection totals.
10. Empty dashboards show zeros or empty states, never sample activity.
11. Switching the application role immediately hides and disables the other role's inputs; the server independently rejects missing or invalid role-specific data.
12. Flash messages and form-error summaries open in one centered, keyboard-accessible dialog, while inline field errors remain visible.
13. Three failed sign-in attempts lock that email for three minutes; a successful sign-in clears the counter.
14. Three failed security answers unlock the private manual recovery report, but do not reset the password.
15. A recovery code is one-time, expires after 24 hours, and clears both security-answer and sign-in lockouts only after a successful password reset.

Seeded accounts use the password `demo123`:

- `jana@repaso.test` — examinee
- `contributor@repaso.test` — content contributor
- `admin@repaso.test` — administrator

When the database is unavailable, sign-in is disabled. The application does not create demo sessions or display fabricated catalog and analytics records.

## Security notes

- Passwords use `password_hash()` and `password_verify()`.
- Security answers use normalized input and `password_hash()`; administrators cannot read them. Recovery codes are stored only as SHA-256 hashes.
- SQL operations use prepared PDO statements.
- State-changing forms and JSON requests require CSRF tokens.
- Session cookies are HTTP-only and use SameSite=Lax; production HTTPS adds the Secure flag.
- Uploaded files are checked by MIME type, PDF signature, random server filename, and size.
- Upload and storage folders block script execution and direct listing.
- The reader overlays a user identity watermark. Downloadable PDF copies are generated with FPDI and logged with user, document, date, and IP address.
- The protected reader displays the uploaded PDF itself through a bundled local PDF.js build. Scrolling updates the current page and saved progress, and the sidebar renders real page thumbnails. Authorized delivery supports browser byte-range requests; preview-limited and downloadable copies are generated through the bundled FPDI/FPDF libraries.
- Dynamic watermarking discourages and helps trace redistribution; it cannot prevent screenshots or all forms of reproduction.

## Scheduled tasks

Create Windows Task Scheduler entries with `C:\xampp\php\php.exe` as the program and one script path as the argument. Recommended schedules:

| Script | Schedule |
|---|---|
| `cron/subscription_checker.php` | Daily at 12:00 AM |
| `cron/backup_database.php` | Daily at 2:00 AM |
| `cron/cleanup_logs.php` | Sunday at 3:00 AM |
| `cron/watermark_cleanup.php` | Hourly |
| `cron/progress_backup.php` | Every 6 hours |
| `cron/notification_sender.php` | Hourly |
| `cron/generate_reports.php` | Daily at 12:05 AM |
| `cron/database_optimizer.php` | Sunday at 4:00 AM |
| `cron/security_monitor.php` | Every 15 minutes |
| `cron/pdf_scheduler.php` | Hourly |
| `cron/payment_reconciliation.php` | Every 15 minutes |

Example arguments: `C:\xampp\htdocs\REPASO\cron\backup_database.php`

## Production checklist

- Disable the database-unavailable demo behavior if it is not wanted.
- Set strong database credentials and restrict the database account to `repaso_db`.
- Configure SMTP and test queue delivery.
- Keep the built-in three-attempt/three-minute sign-in lockout enabled and add proxy-level throttling for production-scale abuse protection.
- Serve the site through HTTPS and set a strict Content Security Policy after confirming all deployment origins.
- Store backups outside the public web root and test restoration.
- Test uploaded-PDF viewing, scroll-based progress, page thumbnails, audited admin preview, preview page limits, and watermarked downloads after every PHP or web-server upgrade. PDF.js is served locally from `assets/vendor/pdfjs`, so the reader does not depend on a third-party CDN.
