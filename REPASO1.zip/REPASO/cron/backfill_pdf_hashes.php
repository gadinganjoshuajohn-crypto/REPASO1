<?php
require __DIR__.'/_bootstrap.php';
$seen=[];$verified=0;$duplicates=0;$missing=0;
$rows=$db->query('SELECT id,filename,content_sha256 FROM pdf_files ORDER BY id')->fetchAll();
foreach($rows as $row){
    $path=REPASO_ROOT.'/uploads/pdfs/'.basename((string)$row['filename']);
    if(!is_file($path)){$q=$db->prepare("UPDATE pdf_files SET hash_status='missing' WHERE id=?");$q->execute([$row['id']]);$missing++;continue;}
    $hash=hash_file('sha256',$path);
    if(isset($seen[$hash])){$q=$db->prepare("UPDATE pdf_files SET content_sha256=NULL,hash_status='duplicate',duplicate_of_pdf_id=? WHERE id=?");$q->execute([$seen[$hash],$row['id']]);$duplicates++;continue;}
    $seen[$hash]=(int)$row['id'];$q=$db->prepare("UPDATE pdf_files SET content_sha256=?,hash_status='verified',duplicate_of_pdf_id=NULL WHERE id=?");$q->execute([$hash,$row['id']]);$verified++;
}
$message="Hash backfill: $verified verified; $duplicates historical duplicates flagged; $missing source files missing";
cron_log($db,'PDF Hash Backfill',$message,$duplicates||$missing?'warning':'info');echo $message.PHP_EOL;
