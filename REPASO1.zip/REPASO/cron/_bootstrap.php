<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'){http_response_code(403);exit("CLI only\n");}
require_once dirname(__DIR__).'/includes/bootstrap.php';
$db=Database::connection();if(!$db){fwrite(STDERR,"Database unavailable\n");exit(1);}
function cron_log(PDO $db,string $task,string $message,string $level='info'):void{$stmt=$db->prepare('INSERT INTO system_logs(activity,level) VALUES(?,?)');$stmt->execute([$task.': '.$message,$level]);$stmt=$db->prepare('INSERT INTO scheduled_tasks(task_name,last_run,status,last_message) VALUES(?,NOW(),?,?) ON DUPLICATE KEY UPDATE last_run=NOW(),status=VALUES(status),last_message=VALUES(last_message)');$stmt->execute([$task,$level==='error'?'Failed':'Success',$message]);echo "[$task] $message\n";}
