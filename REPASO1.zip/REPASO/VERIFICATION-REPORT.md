# REPASO verification report

Date: 2026-11-09 (Asia/Manila)

## Test environment

- PHP 8.2.12 and MariaDB 10.4.32 from XAMPP.
- Isolated database: `repaso_test`. The existing `repaso_db` was not modified.
- Base schema plus the platform, role-policy, recovery, and `2026_11_09_ownership_payments_catalog.sql` migrations applied successfully: 42 tables.
- The legacy `2026_10_01_add_reviewer_covers.sql` was not applied to a fresh install because the supplied base schema already contains those cover columns.

## Executed and passed

`tests/security_smoke.php` passed PHP lint, authorization guards, checkout boundary assertions, and test webhook signature verification.

`tests/integration_database.php` passed 17 database-backed assertions:

1. Free candidate receives only the configured preview.
2. Direct download cannot use preview fallback.
3. Individual entitlement takes precedence over preview.
4. Concurrent fulfillment creates one subscription grant.
5. Concurrent fulfillment records revenue once.
6. Concurrent fulfillment leaves the order paid.
7. Paid subscription takes precedence over preview.
8. Early renewal begins at the existing expiry.
9. Provider amount mismatch is rejected.
10. Rejected provider payload grants no access.
11. Partial refund preserves the paid grant.
12. Partial refund is separately recorded in reporting.
13. Full refund affects only its purchase.
14. A later unrelated renewal is rebased so it remains immediately usable.
15. Protected preview output contains one configured page.
16. Authorized protected output contains all three source pages.
17. Simultaneous renamed uploads produce one listing and one privacy-safe duplicate rejection.

Actual HTTP endpoint/browser-surface checks also passed:

- signed webhook first delivery failed with HTTP 500, the same event ID retried successfully with HTTP 200, and its attempt count became 2;
- a third duplicate delivery returned HTTP 200 while retaining one subscription and one revenue row;
- invalid webhook signature returned HTTP 401;
- admin and contributor Published Catalog pages returned HTTP 200 with their own square management actions;
- candidate catalog contains no management action;
- cross-role archive requests returned HTTP 403;
- authorized admin/contributor archival retained historical rows; an active entitlement remained valid and the admin action was audited;
- admin Submit PDF created a server-owned `repaso` record with the uploading admin, verified rights, review status, and a 64-character SHA-256;
- the same bytes uploaded under a different contributor filename were rejected without revealing the original title;
- admin acquisition POST retained contributor ownership, flagged transfer review, recorded ₱1,250.50 as a private acquisition expense, and created no contributor buyout earning;
- candidate access to the private acquisition page returned HTTP 403;
- preview stream returned exactly one page, paid stream returned all three pages, and an unauthorized direct download returned HTTP 403;
- payment return pages rendered pending, paid, cancelled, failed, and refunded states;
- ownership finance report rendered separate REPASO revenue, acquisition expense, contributor obligation, and unallocated subscription-share metrics.

Demo GCash simulator checks passed:

- pricing page visibly identifies demo payment mode;
- checkout opens a simulation page stating that no money will be collected;
- simulated success produces a paid test order, one subscription grant, and one test revenue row;
- repeating simulated success remains idempotent with one grant and one revenue row;
- simulated pending, failed, and cancelled actions render and persist the matching status;
- demo revenue produces zero live-revenue rows;
- `REPASO_DEMO_PAYMENTS=1` is ignored when `REPASO_PAYMONGO_MODE=live`.

## Remaining external test

A real PayMongo-hosted GCash sandbox checkout was not executed because no `sk_test_...` key, test webhook signing secret, or public HTTPS callback URL is configured on this machine. The local integration used authentic raw-body HMAC verification and official Checkout Session webhook shapes, but it did not contact PayMongo.

After adding those three configuration values, perform one controlled PayMongo test checkout and refund using `PAYMONGO-SETUP.md`. Live mode additionally depends on PayMongo KYC/merchant approval and GCash activation.

## Business-policy decision still required

The supplied project does not define a complete subscription-share formula. Subscription revenue is recorded in `subscription_share_allocations` as `unallocated`; no contributor earning is invented until the eligible usage signal, allocation formula, rounding, vesting, and refund rules are approved. Individual contributor commissions continue to use accepted agreement snapshots. REPASO-owned PDFs never create contributor earnings.
