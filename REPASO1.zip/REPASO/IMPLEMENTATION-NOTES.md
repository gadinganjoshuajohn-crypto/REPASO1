# REPASO update — November 3, 2026

## Required deployment step

Back up the existing database, then apply:

`database/migrations/2026_11_03_account_recovery_and_profiles.sql`

This migration adds security-question recovery, three-attempt login lockouts, manual recovery requests, one-time admin codes, and profile-image support. Existing data is retained.

Ensure these paths are writable by Apache/PHP:

- `uploads/profiles`
- `storage/evidence`

The existing `storage/.htaccess` and `storage/evidence/.htaccess` protections must remain in place so identity documents cannot be opened directly from the web.

## Major changes

- Five security questions are available to both candidate and contributor applicants.
- Three incorrect security answers unlock the private manual recovery request with proof-of-ownership evidence and an incident report.
- Administrators can review recovery requests and issue a 24-hour, one-time code from **Admin → Recovery requests**.
- Three failed sign-in attempts lock the email for three minutes.
- Profile photos are supported in every role's shared profile page and navigation chip.
- Admin reports now include orders, live gross revenue, conversion, incomplete checkout, refunds, best sellers, and contributor earnings visuals.
- Contributor dashboards and reports now include reader demand, purchases, gross/net earnings, balances, conversion, refunds, and best-seller visuals.
- Contributor signup, reviewer submission, and reviewer editing include an **Other** profession/subject option. Every word in custom catalog labels is capitalized on the server (for example, `civil engineering` becomes `Civil Engineering`) and remains subject to PDF moderation.
- Homepage, shared dashboards, subscription cards, spacing, and colors now use the approved burgundy/parchment/cream/mist-blue palette. Plan badges use Forest Green (`#228B22`).
- Admin audited preview and the protected reader now open the actual uploaded PDF instead of the demonstration page. Inline viewing supports byte-range responses, while preview-limited and downloadable copies use the bundled FPDI/FPDF dependencies; missing files or generation failures return controlled errors instead of PHP stack traces.
- The reader now uses bundled PDF.js page canvases: scrolling changes the header page number and progress automatically, and every sidebar item is an actual PDF thumbnail. Notes open in an accessible in-page dialog instead of a browser prompt; bookmark and notes screens use aligned saved-page cards.
- Minimal red attention dots and a compact notification panel surface pending PDF/application reviews for administrators, confirmed purchases for contributors, and newly available reviewers for candidates. Opening the relevant destination clears the indicator for the current session and shows one brief confirmation toast.

## Verification completed

- PHP syntax: 62 files passed.
- JavaScript syntax: passed.
- Actual uploaded 13-page PDF: page rendering and reader page navigation passed.
- Scroll tracking, actual page thumbnails, in-page note dialog, bookmarks layout, attention dots, and notification panel: browser verified.
- Bookmark links now retain their requested page while the reader initializes; dashboard selects share a consistent custom style, compact moderation controls are aligned, and header notifications/profile controls are anchored to the right edge.
- Bundled FPDI/FPDF and PHPMailer class loading: passed.
- Existing `tests/security_smoke.php`: passed.
- Browser checks: homepage, login, forgot-password, and registration pages returned HTTP 200; no browser console errors were reported.
