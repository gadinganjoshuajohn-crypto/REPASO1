<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/layout.php';
page_start('Your Digital Reviewer Hub.', 'public');
?>
<section class="hero">
  <div class="hero-copy">
    <div class="eyebrow">Secure professional licensure reviewer library</div>
    <h1 class="brand-hero">REPASO<span>Your Digital Reviewer Hub.</span></h1>
    <p class="lead">A centralized, protected study library for candidates preparing for selected professional licensure examinations.</p>
    <ul class="feature-list">
      <li><span><?= icon('library') ?></span>Organized by examination and subject</li>
      <li><span><?= icon('shield') ?></span>Protected with personalized watermarks</li>
      <li><span><?= icon('offline') ?></span>Read online or save authorized materials offline</li>
      <li><span><?= icon('play') ?></span>Preview selected pages before subscribing</li>
    </ul>
    <div class="hero-actions"><a class="button gold" href="register.php">Start your review journey <?= icon('chevron') ?></a><a class="button ghost" href="pricing.php">Explore access plans</a></div><div class="home-proof"><span><b>Purpose-built</b> for board exam preparation</span><span><b>Verified</b> contributor workflow</span><span><b>Protected</b> reading environment</span></div>
  </div>
  <div class="hero-art" aria-label="Student reviewing with a tablet and notebook">
    <span class="float-icon one"><?= icon('library',28) ?></span><span class="float-icon two"><?= icon('notes',28) ?></span>
    <img src="<?= e(asset('images/hero-student.png')) ?>" alt="A student preparing for a professional examination">
  </div>
</section>
<section class="marketing-section" id="features">
  <div class="section-intro"><div class="eyebrow">One focused study space</div><h2>From scattered files to a review plan you can trust.</h2><p class="muted">REPASO brings authorized reviewer materials, reading tools, and progress into one organized workspace.</p></div>
  <div class="feature-grid">
    <article class="feature-card"><span class="feature-icon"><?= icon('search',24) ?></span><h3>Find the right material</h3><p class="muted">Search by examination, category, subject, title, or contributor.</p></article>
    <article class="feature-card"><span class="feature-icon"><?= icon('bookmark',24) ?></span><h3>Keep your place</h3><p class="muted">Save pages, write notes, and resume from your latest reading position.</p></article>
    <article class="feature-card"><span class="feature-icon"><?= icon('shield',24) ?></span><h3>Respect every contributor</h3><p class="muted">Personalized document watermarks support responsible access and traceability.</p></article>
  </div>
</section>
<section class="marketing-section audience-section"><div class="section-intro"><div class="eyebrow">One platform, two focused experiences</div><h2>Built around the people who make review possible.</h2></div><div class="audience-grid"><article class="audience-card candidate-card"><span><?=icon('notes',28)?></span><div><small>For candidates</small><h3>Study with structure, not clutter.</h3><p>Build a personal library, keep notes and bookmarks, continue offline, and see meaningful progress.</p><a href="register.php">Apply as a candidate <?=icon('chevron')?></a></div></article><article class="audience-card contributor-card"><span><?=icon('chart',28)?></span><div><small>For contributors</small><h3>Publish responsibly. Learn what performs.</h3><p>Submit verified materials, manage covers and rights details, and track reader and earnings insights.</p><a href="register.php">Apply as a contributor <?=icon('chevron')?></a></div></article></div></section>
<section class="marketing-section tint" id="about">
  <div class="trust-row"><div><div class="eyebrow">Designed for real access conditions</div><h2>Study continues when connectivity does not.</h2><p class="muted">Authorized subscribers can save selected materials to the encrypted offline shelf, while device limits and access controls protect the reviewer library.</p><a class="button navy" href="register.php">Create your account</a></div><div class="stat-band"><div><strong>3</strong><span>reviewer categories</span></div><div><strong>20</strong><span>offline slots</span></div><div><strong>10</strong><span>free preview pages</span></div></div></div>
</section>
<footer class="site-footer"><div><strong>REPASO</strong><br><span>Your Digital Reviewer Hub.</span></div><span>© 2026 REPASO · Metro Dumaguete College capstone project</span></footer>
<?php page_end('public'); ?>
