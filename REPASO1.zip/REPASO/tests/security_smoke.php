<?php
declare(strict_types=1);
$root=dirname(__DIR__);$failures=[];
foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root)) as $file){if($file->isFile()&&$file->getExtension()==='php'&&!str_contains($file->getPathname(),DIRECTORY_SEPARATOR.'vendor'.DIRECTORY_SEPARATOR)){$output=[];$code=0;exec(escapeshellarg(PHP_BINARY).' -l '.escapeshellarg($file->getPathname()),$output,$code);if($code!==0)$failures[]='Syntax: '.$file->getPathname();}}
$checks=[
 'api/paymongo-webhook.php'=>['paymongo_signature_valid','payment_webhook_events','confirm_checkout_session','processing_status'],
 'pdf/stream.php'=>['can_access_pdf','contributor_id=?','record_usage'],
 'switch-profile.php'=>['user_id=? AND role=? AND status="approved"'],
 'admin/evidence.php'=>['require_role(\'admin\')','admin_audit_log'],
 'api/checkout.php'=>['candidate_plans','amount_centavos','duration_days_snapshot','v2/checkout_sessions','payment_method_types'],
 'demo-gcash.php'=>['demo_payments_enabled','SIMULATION · NO MONEY WILL BE COLLECTED','confirm_paid_order','demo_gcash'],
 'includes/functions.php'=>['pdf_entitlements','subscription_included','validated_pdf_upload','content_sha256'],
 'contributor/archive.php'=>['verify_csrf','owner_type="contributor"','status="archived"'],
 'admin/archive-pdf.php'=>['verify_csrf','owner_type="repaso"','status="archived"'],
 'register.php'=>['eligibility_applications','storage/evidence','data-role-application','data-role-section="candidate"','data-role-section="contributor"','candidate_profession_id','contributor_profession_id','Choose an account type'],
 'assets/js/app.js'=>['section.disabled=!active','notification-overlay','aria-modal','data-confirm-cancel','data-confirm-accept'],
 'application-status.php'=>['needs_revision','resubmission_count=resubmission_count+1','application_history'],
];
foreach($checks as $path=>$needles){$source=file_get_contents($root.'/'.$path);foreach($needles as $needle)if(!str_contains($source,$needle))$failures[]="$path missing $needle";}
$accessSource=file_get_contents($root.'/includes/functions.php');$entitlementPos=strpos($accessSource,"table_exists(\$db,'pdf_entitlements')");$previewPos=strpos($accessSource,"return [true,'preview']");if($entitlementPos===false||$previewPos===false||$entitlementPos>$previewPos)$failures[]='Paid PDF grants must be checked before preview fallback';
require_once $root.'/includes/payments.php';putenv('REPASO_PAYMONGO_WEBHOOK_SECRET_TEST=smoke-secret');$raw='{"data":{"id":"evt_test","attributes":{"livemode":false}}}';$t=(string)time();$sig=hash_hmac('sha256',$t.'.'.$raw,'smoke-secret');if(!paymongo_signature_valid($raw,"t=$t,te=$sig",false))$failures[]='Valid webhook signature rejected';if(paymongo_signature_valid($raw,"t=$t,te=invalid",false))$failures[]='Invalid webhook signature accepted';
if($failures){fwrite(STDERR,"FAIL\n- ".implode("\n- ",$failures)."\n");exit(1);}echo "PASS: PHP syntax, authorization guards, payment boundary, and webhook signature smoke checks.\n";
