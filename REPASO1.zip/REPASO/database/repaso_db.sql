CREATE DATABASE IF NOT EXISTS repaso_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE repaso_db;

CREATE TABLE users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  fullname VARCHAR(150) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('examinee','contributor','admin') NOT NULL DEFAULT 'examinee',
  subscription ENUM('free','basic','premium') NOT NULL DEFAULT 'free',
  subscription_end DATETIME NULL,
  status ENUM('active','suspended','deleted') NOT NULL DEFAULT 'active',
  profile_image VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_users_role_status(role,status)
) ENGINE=InnoDB;

CREATE TABLE categories (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  category_name VARCHAR(80) NOT NULL UNIQUE,
  description TEXT NULL
) ENGINE=InnoDB;

CREATE TABLE subjects (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  category_id INT UNSIGNED NOT NULL,
  subject_name VARCHAR(150) NOT NULL,
  FOREIGN KEY(category_id) REFERENCES categories(id) ON DELETE CASCADE,
  UNIQUE KEY uq_subject(category_id,subject_name)
) ENGINE=InnoDB;

CREATE TABLE pdf_files (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(220) NOT NULL,
  description TEXT NULL,
  filename VARCHAR(255) NOT NULL UNIQUE,
  cover_filename VARCHAR(255) NULL,
  cover_position_x TINYINT UNSIGNED NOT NULL DEFAULT 50,
  cover_position_y TINYINT UNSIGNED NOT NULL DEFAULT 50,
  category_id INT UNSIGNED NOT NULL,
  subject_id INT UNSIGNED NULL,
  contributor_id INT UNSIGNED NOT NULL,
  pages INT UNSIGNED NOT NULL DEFAULT 0,
  free_pages INT UNSIGNED NOT NULL DEFAULT 10,
  access_level ENUM('free','basic','premium') NOT NULL DEFAULT 'premium',
  status ENUM('draft','review','scheduled','published','archived','rejected') NOT NULL DEFAULT 'draft',
  release_date DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY(category_id) REFERENCES categories(id),
  FOREIGN KEY(subject_id) REFERENCES subjects(id) ON DELETE SET NULL,
  FOREIGN KEY(contributor_id) REFERENCES users(id),
  FULLTEXT KEY ft_pdf(title,description)
) ENGINE=InnoDB;

CREATE TABLE reading_progress (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  pdf_id INT UNSIGNED NOT NULL,
  current_page INT UNSIGNED NOT NULL DEFAULT 1,
  percentage DECIMAL(5,2) NOT NULL DEFAULT 0,
  last_opened_at DATETIME NULL,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY(pdf_id) REFERENCES pdf_files(id) ON DELETE CASCADE,
  UNIQUE KEY uq_progress(user_id,pdf_id)
) ENGINE=InnoDB;

CREATE TABLE bookmarks (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  pdf_id INT UNSIGNED NOT NULL,
  page_number INT UNSIGNED NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY(pdf_id) REFERENCES pdf_files(id) ON DELETE CASCADE,
  UNIQUE KEY uq_bookmark(user_id,pdf_id,page_number)
) ENGINE=InnoDB;

CREATE TABLE notes (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  pdf_id INT UNSIGNED NOT NULL,
  page INT UNSIGNED NOT NULL,
  note TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY(pdf_id) REFERENCES pdf_files(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE subscriptions (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  plan ENUM('basic','premium') NOT NULL,
  start_date DATETIME NOT NULL,
  end_date DATETIME NOT NULL,
  status ENUM('pending','active','expired','cancelled') NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_subscription_expiry(status,end_date)
) ENGINE=InnoDB;

CREATE TABLE subscription_requests (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  plan ENUM('basic','premium') NOT NULL,
  payment_reference VARCHAR(190) NOT NULL,
  status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE offline_downloads (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  pdf_id INT UNSIGNED NOT NULL,
  device_hash CHAR(64) NOT NULL,
  expires_at DATETIME NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY(pdf_id) REFERENCES pdf_files(id) ON DELETE CASCADE,
  UNIQUE KEY uq_offline_device(user_id,pdf_id,device_hash)
) ENGINE=InnoDB;

CREATE TABLE watermark_logs (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  pdf_id INT UNSIGNED NOT NULL,
  date_accessed TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  ip_address VARCHAR(45) NULL,
  output_file VARCHAR(255) NULL,
  FOREIGN KEY(user_id) REFERENCES users(id),
  FOREIGN KEY(pdf_id) REFERENCES pdf_files(id),
  INDEX idx_watermark_date(date_accessed)
) ENGINE=InnoDB;

CREATE TABLE notifications (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  message TEXT NOT NULL,
  notification_type VARCHAR(60) NOT NULL DEFAULT 'system',
  status ENUM('Unread','Read','Queued','Sent','Failed') NOT NULL DEFAULT 'Unread',
  send_after DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_notification_queue(status,send_after)
) ENGINE=InnoDB;

CREATE TABLE progress_backup (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  pdf_id INT UNSIGNED NOT NULL,
  page INT UNSIGNED NOT NULL,
  percentage DECIMAL(5,2) NOT NULL,
  backup_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_progress_backup_date(backup_date)
) ENGINE=InnoDB;

CREATE TABLE scheduled_tasks (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  task_name VARCHAR(100) NOT NULL UNIQUE,
  last_run DATETIME NULL,
  next_run DATETIME NULL,
  status ENUM('Idle','Running','Success','Failed') NOT NULL DEFAULT 'Idle',
  last_message VARCHAR(255) NULL
) ENGINE=InnoDB;

CREATE TABLE system_logs (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  activity VARCHAR(255) NOT NULL,
  level ENUM('info','warning','error') NOT NULL DEFAULT 'info',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_system_log_date(created_at)
) ENGINE=InnoDB;

CREATE TABLE security_logs (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NULL,
  event VARCHAR(255) NOT NULL,
  ip_address VARCHAR(45) NULL,
  date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  status ENUM('open','reviewed','resolved') NOT NULL DEFAULT 'open',
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_security_status(status,date)
) ENGINE=InnoDB;

CREATE TABLE login_attempts (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(190) NOT NULL,
  ip_address VARCHAR(45) NOT NULL,
  succeeded TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_attempt_lookup(email,ip_address,created_at)
) ENGINE=InnoDB;

CREATE TABLE account_security (
  user_id INT UNSIGNED PRIMARY KEY,
  security_question VARCHAR(190) NOT NULL,
  security_answer_hash VARCHAR(255) NOT NULL,
  failed_answers TINYINT UNSIGNED NOT NULL DEFAULT 0,
  locked_at DATETIME NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE login_lockouts (
  email VARCHAR(190) PRIMARY KEY,
  failed_attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
  locked_until DATETIME NULL,
  last_ip VARCHAR(45) NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE account_recovery_requests (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  evidence_storage_name VARCHAR(255) NOT NULL,
  evidence_original_name VARCHAR(255) NOT NULL,
  evidence_mime VARCHAR(100) NOT NULL,
  evidence_size_bytes INT UNSIGNED NOT NULL,
  incident_report TEXT NOT NULL,
  status ENUM('pending','code_issued','completed','rejected') NOT NULL DEFAULT 'pending',
  recovery_code_hash CHAR(64) NULL,
  code_expires_at DATETIME NULL,
  code_used_at DATETIME NULL,
  reviewed_by INT UNSIGNED NULL,
  admin_note TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  reviewed_at DATETIME NULL,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY(reviewed_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

INSERT INTO categories(category_name,description) VALUES
('GenEd','General Education reviewers'),('ProfEd','Professional Education reviewers'),('Major','Specialization reviewers');

INSERT INTO users(fullname,email,password,role,subscription,status) VALUES
('REPASO Administrator','admin@repaso.test','$2y$10$t8SiKr3qp7Mni03fYcd9He9eOO5ixHkiMUdTnWrXo0f391zP4HoOe','admin','premium','active'),
('Maria Santos','contributor@repaso.test','$2y$10$t8SiKr3qp7Mni03fYcd9He9eOO5ixHkiMUdTnWrXo0f391zP4HoOe','contributor','premium','active'),
('Jana Dela Cruz','jana@repaso.test','$2y$10$t8SiKr3qp7Mni03fYcd9He9eOO5ixHkiMUdTnWrXo0f391zP4HoOe','examinee','premium','active');

INSERT INTO scheduled_tasks(task_name,status) VALUES
('Subscription Checker','Idle'),('Database Backup','Idle'),('Log Cleanup','Idle'),('Watermark Cleanup','Idle'),('Progress Backup','Idle'),('Notification Sender','Idle'),('Analytics Report','Idle'),('Database Optimizer','Idle'),('Security Monitor','Idle'),('PDF Scheduler','Idle');
