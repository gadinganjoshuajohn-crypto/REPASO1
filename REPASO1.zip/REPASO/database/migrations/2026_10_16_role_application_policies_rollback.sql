USE repaso_db;
DROP TABLE IF EXISTS eligibility_policies;
