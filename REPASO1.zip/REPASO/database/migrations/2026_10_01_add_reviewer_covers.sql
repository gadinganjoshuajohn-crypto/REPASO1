USE repaso_db;

ALTER TABLE pdf_files
  ADD COLUMN cover_filename VARCHAR(255) NULL AFTER filename,
  ADD COLUMN cover_position_x TINYINT UNSIGNED NOT NULL DEFAULT 50 AFTER cover_filename,
  ADD COLUMN cover_position_y TINYINT UNSIGNED NOT NULL DEFAULT 50 AFTER cover_position_x;
