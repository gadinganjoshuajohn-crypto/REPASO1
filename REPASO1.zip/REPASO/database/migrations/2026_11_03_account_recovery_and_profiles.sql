USE repaso_db;

ALTER TABLE users
  ADD COLUMN IF NOT EXISTS profile_image VARCHAR(255) NULL AFTER status;

ALTER TABLE eligibility_applications
  ADD COLUMN IF NOT EXISTS security_question VARCHAR(190) NULL AFTER password_hash,
  ADD COLUMN IF NOT EXISTS security_answer_hash VARCHAR(255) NULL AFTER security_question;

CREATE TABLE IF NOT EXISTS account_security (
  user_id INT UNSIGNED PRIMARY KEY,
  security_question VARCHAR(190) NOT NULL,
  security_answer_hash VARCHAR(255) NOT NULL,
  failed_answers TINYINT UNSIGNED NOT NULL DEFAULT 0,
  locked_at DATETIME NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS login_lockouts (
  email VARCHAR(190) PRIMARY KEY,
  failed_attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
  locked_until DATETIME NULL,
  last_ip VARCHAR(45) NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_login_locked_until(locked_until)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS account_recovery_requests (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  evidence_storage_name VARCHAR(255) NOT NULL,
  evidence_original_name VARCHAR(255) NOT NULL,
  evidence_mime VARCHAR(100) NOT NULL,
  evidence_size_bytes INT UNSIGNED NOT NULL,
  incident_report TEXT NOT NULL,
  status ENUM('pending','code_issued','completed','rejected') NOT NULL DEFAULT 'pending',
  recovery_code_hash CHAR(64) NULL,
  code_expires_at DATETIME NULL,
  code_used_at DATETIME NULL,
  reviewed_by INT UNSIGNED NULL,
  admin_note TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  reviewed_at DATETIME NULL,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY(reviewed_by) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_recovery_status(status,created_at)
) ENGINE=InnoDB;
