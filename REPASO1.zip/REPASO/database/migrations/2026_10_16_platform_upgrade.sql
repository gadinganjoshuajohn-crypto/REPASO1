-- REPASO platform upgrade. Apply after database/repaso_db.sql and the cover migration.
-- Existing users and PDFs are preserved. Legacy non-admin accounts are flagged for review.
USE repaso_db;

CREATE TABLE professions (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL UNIQUE,
  slug VARCHAR(160) NOT NULL UNIQUE,
  description TEXT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

ALTER TABLE subjects
  ADD INDEX idx_subject_category(category_id),
  DROP INDEX uq_subject,
  ADD COLUMN profession_id INT UNSIGNED NULL AFTER id,
  ADD COLUMN description TEXT NULL,
  ADD COLUMN is_active TINYINT(1) NOT NULL DEFAULT 1,
  ADD INDEX idx_subject_profession_active(profession_id,is_active),
  ADD CONSTRAINT fk_subject_profession FOREIGN KEY(profession_id) REFERENCES professions(id);
ALTER TABLE subjects ADD UNIQUE KEY uq_subject_profession(profession_id,subject_name);

INSERT INTO professions(name,slug,description) VALUES
('Teacher Education','teacher-education','Configurable reviewer catalog for teacher education candidates');
SET @teacher_profession_id=LAST_INSERT_ID();
UPDATE subjects SET profession_id=@teacher_profession_id WHERE profession_id IS NULL;
INSERT INTO subjects(profession_id,category_id,subject_name,description,is_active)
SELECT @teacher_profession_id,c.id,c.category_name,c.description,1
FROM categories c WHERE NOT EXISTS (SELECT 1 FROM subjects s WHERE s.profession_id=@teacher_profession_id AND s.subject_name=c.category_name);

ALTER TABLE pdf_files
  ADD COLUMN profession_id INT UNSIGNED NULL AFTER cover_position_y,
  ADD COLUMN access_policy ENUM('free','subscription','individual','subscription_or_individual') NOT NULL DEFAULT 'subscription' AFTER free_pages,
  ADD COLUMN price_centavos INT UNSIGNED NULL AFTER access_policy,
  ADD COLUMN individual_access_days SMALLINT UNSIGNED NULL AFTER price_centavos,
  ADD COLUMN subscription_included TINYINT(1) NOT NULL DEFAULT 1 AFTER individual_access_days,
  ADD COLUMN rights_status ENUM('pending','verified','rejected') NOT NULL DEFAULT 'pending',
  ADD COLUMN rights_note TEXT NULL,
  ADD INDEX idx_pdf_catalog(profession_id,subject_id,status),
  ADD CONSTRAINT fk_pdf_profession FOREIGN KEY(profession_id) REFERENCES professions(id);
UPDATE pdf_files SET profession_id=@teacher_profession_id WHERE profession_id IS NULL;
UPDATE pdf_files p JOIN categories c ON c.id=p.category_id
LEFT JOIN subjects s ON s.profession_id=@teacher_profession_id AND s.subject_name=c.category_name
SET p.subject_id=COALESCE(p.subject_id,s.id), p.access_policy=IF(p.access_level='free','free','subscription');

CREATE TABLE role_profiles (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  role ENUM('candidate','contributor') NOT NULL,
  status ENUM('pending','approved','suspended','inactive') NOT NULL DEFAULT 'pending',
  profession_id INT UNSIGNED NULL,
  verified_badge ENUM('none','board_passer','topnotcher') NOT NULL DEFAULT 'none',
  verified_rank VARCHAR(50) NULL,
  approved_at DATETIME NULL,
  approved_by INT UNSIGNED NULL,
  legacy_review_required TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_user_role(user_id,role),
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY(profession_id) REFERENCES professions(id),
  FOREIGN KEY(approved_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

INSERT INTO role_profiles(user_id,role,status,legacy_review_required,approved_at)
SELECT id,IF(role='examinee','candidate','contributor'),'approved',1,NOW()
FROM users WHERE role IN ('examinee','contributor');

CREATE TABLE eligibility_applications (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NULL,
  email VARCHAR(190) NOT NULL,
  full_name VARCHAR(150) NOT NULL,
  password_hash VARCHAR(255) NULL,
  requested_role ENUM('candidate','contributor') NOT NULL,
  profession_id INT UNSIGNED NOT NULL,
  qualification ENUM('candidate_purpose','board_passer','topnotcher') NOT NULL,
  exam_name VARCHAR(190) NULL,
  exam_month TINYINT UNSIGNED NULL,
  exam_year SMALLINT UNSIGNED NULL,
  placement VARCHAR(50) NULL,
  verification_details TEXT NULL,
  purpose_statement TEXT NULL,
  rights_declaration TINYINT(1) NOT NULL DEFAULT 0,
  terms_accepted_at DATETIME NOT NULL,
  identity_reuse_consent_at DATETIME NULL,
  email_verified_at DATETIME NULL,
  status ENUM('pending','needs_revision','approved','rejected','withdrawn') NOT NULL DEFAULT 'pending',
  public_token_hash CHAR(64) NOT NULL,
  reviewed_by INT UNSIGNED NULL,
  decision_at DATETIME NULL,
  decision_reason TEXT NULL,
  resubmission_count SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_application_token(public_token_hash),
  INDEX idx_application_duplicate(email,requested_role,status),
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY(profession_id) REFERENCES professions(id),
  FOREIGN KEY(reviewed_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE application_evidence (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  application_id BIGINT UNSIGNED NOT NULL,
  storage_name VARCHAR(255) NOT NULL,
  original_name VARCHAR(255) NOT NULL,
  mime_type VARCHAR(80) NOT NULL,
  size_bytes INT UNSIGNED NOT NULL,
  sha256 CHAR(64) NOT NULL,
  retention_until DATE NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(application_id) REFERENCES eligibility_applications(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE application_history (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  application_id BIGINT UNSIGNED NOT NULL,
  actor_user_id INT UNSIGNED NULL,
  from_status VARCHAR(30) NULL,
  to_status VARCHAR(30) NOT NULL,
  reason TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(application_id) REFERENCES eligibility_applications(id) ON DELETE CASCADE,
  FOREIGN KEY(actor_user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE activation_tokens (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  token_hash CHAR(64) NOT NULL UNIQUE,
  expires_at DATETIME NOT NULL,
  used_at DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE candidate_plans (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  description TEXT NULL,
  price_centavos INT UNSIGNED NOT NULL,
  duration_days SMALLINT UNSIGNED NOT NULL,
  renewal_method ENUM('manual','automatic') NOT NULL DEFAULT 'manual',
  refund_policy TEXT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;
INSERT INTO candidate_plans(name,description,price_centavos,duration_days,renewal_method,refund_policy)
VALUES ('Premium 30 Days','Access to materials explicitly included by their access policy.',29900,30,'manual','Refunds are reviewed under the configured REPASO policy.');

CREATE TABLE orders (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_number VARCHAR(40) NOT NULL UNIQUE,
  candidate_profile_id BIGINT UNSIGNED NOT NULL,
  order_type ENUM('subscription','pdf_purchase') NOT NULL,
  plan_id INT UNSIGNED NULL,
  pdf_id INT UNSIGNED NULL,
  amount_centavos INT UNSIGNED NOT NULL,
  currency CHAR(3) NOT NULL DEFAULT 'PHP',
  promo_id BIGINT UNSIGNED NULL,
  status ENUM('pending','paid','failed','expired','cancelled','refunded') NOT NULL DEFAULT 'pending',
  environment ENUM('test','live','manual') NOT NULL DEFAULT 'test',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  paid_at DATETIME NULL,
  FOREIGN KEY(candidate_profile_id) REFERENCES role_profiles(id),
  FOREIGN KEY(plan_id) REFERENCES candidate_plans(id),
  FOREIGN KEY(pdf_id) REFERENCES pdf_files(id)
) ENGINE=InnoDB;

CREATE TABLE payments (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id BIGINT UNSIGNED NOT NULL,
  provider VARCHAR(40) NOT NULL,
  provider_checkout_id VARCHAR(190) NULL,
  provider_payment_id VARCHAR(190) NULL,
  provider_reference VARCHAR(190) NULL,
  amount_centavos INT UNSIGNED NOT NULL,
  currency CHAR(3) NOT NULL DEFAULT 'PHP',
  status ENUM('pending','paid','failed','expired','cancelled','refunded') NOT NULL DEFAULT 'pending',
  confirmed_at DATETIME NULL,
  raw_payload JSON NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_provider_payment(provider,provider_payment_id),
  FOREIGN KEY(order_id) REFERENCES orders(id)
) ENGINE=InnoDB;

CREATE TABLE payment_webhook_events (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  provider VARCHAR(40) NOT NULL,
  event_id VARCHAR(190) NOT NULL,
  event_type VARCHAR(100) NOT NULL,
  payload_hash CHAR(64) NOT NULL,
  processed_at DATETIME NULL,
  result VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_provider_event(provider,event_id)
) ENGINE=InnoDB;

ALTER TABLE subscriptions
  ADD COLUMN candidate_profile_id BIGINT UNSIGNED NULL,
  ADD COLUMN order_id BIGINT UNSIGNED NULL,
  ADD COLUMN plan_id INT UNSIGNED NULL,
  ADD UNIQUE KEY uq_subscription_order(order_id),
  ADD FOREIGN KEY(candidate_profile_id) REFERENCES role_profiles(id),
  ADD FOREIGN KEY(order_id) REFERENCES orders(id),
  ADD FOREIGN KEY(plan_id) REFERENCES candidate_plans(id);

CREATE TABLE pdf_entitlements (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  candidate_profile_id BIGINT UNSIGNED NOT NULL,
  pdf_id INT UNSIGNED NOT NULL,
  order_id BIGINT UNSIGNED NULL,
  source ENUM('free','subscription','purchase','admin_grant') NOT NULL,
  starts_at DATETIME NOT NULL,
  expires_at DATETIME NULL,
  revoked_at DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_entitlement_order(candidate_profile_id,pdf_id,order_id),
  FOREIGN KEY(candidate_profile_id) REFERENCES role_profiles(id),
  FOREIGN KEY(pdf_id) REFERENCES pdf_files(id),
  FOREIGN KEY(order_id) REFERENCES orders(id)
) ENGINE=InnoDB;

CREATE TABLE usage_events (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  event_key VARCHAR(190) NOT NULL UNIQUE,
  pdf_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  profile_id BIGINT UNSIGNED NULL,
  event_type ENUM('reader_session','file_delivery','offline_authorization','preview') NOT NULL,
  session_key VARCHAR(128) NULL,
  is_commercial TINYINT(1) NOT NULL DEFAULT 0,
  occurred_at DATETIME NOT NULL,
  metadata JSON NULL,
  FOREIGN KEY(pdf_id) REFERENCES pdf_files(id),
  FOREIGN KEY(user_id) REFERENCES users(id),
  FOREIGN KEY(profile_id) REFERENCES role_profiles(id),
  INDEX idx_usage_report(pdf_id,event_type,occurred_at)
) ENGINE=InnoDB;

CREATE TABLE contributor_agreements (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  contributor_profile_id BIGINT UNSIGNED NOT NULL,
  pdf_id INT UNSIGNED NOT NULL,
  model ENUM('commission','buyout','subscription_share') NOT NULL,
  commission_basis_points SMALLINT UNSIGNED NULL,
  buyout_centavos INT UNSIGNED NULL,
  allocation_rule TEXT NULL,
  rights_scope TEXT NOT NULL,
  effective_at DATETIME NOT NULL,
  accepted_at DATETIME NULL,
  FOREIGN KEY(contributor_profile_id) REFERENCES role_profiles(id),
  FOREIGN KEY(pdf_id) REFERENCES pdf_files(id)
) ENGINE=InnoDB;

CREATE TABLE earnings_ledger (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  contributor_profile_id BIGINT UNSIGNED NOT NULL,
  pdf_id INT UNSIGNED NULL,
  order_id BIGINT UNSIGNED NULL,
  agreement_id BIGINT UNSIGNED NULL,
  entry_type ENUM('sale','commission','buyout','subscription_share','refund','fee','adjustment','payout') NOT NULL,
  gross_centavos INT NOT NULL DEFAULT 0,
  fee_centavos INT NOT NULL DEFAULT 0,
  contributor_centavos INT NOT NULL DEFAULT 0,
  platform_centavos INT NOT NULL DEFAULT 0,
  status ENUM('pending','available','paid','reversed') NOT NULL DEFAULT 'pending',
  rate_snapshot JSON NULL,
  occurred_at DATETIME NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_ledger_order_type(order_id,entry_type,contributor_profile_id),
  FOREIGN KEY(contributor_profile_id) REFERENCES role_profiles(id),
  FOREIGN KEY(pdf_id) REFERENCES pdf_files(id),
  FOREIGN KEY(order_id) REFERENCES orders(id),
  FOREIGN KEY(agreement_id) REFERENCES contributor_agreements(id)
) ENGINE=InnoDB;

CREATE TABLE payouts (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  contributor_profile_id BIGINT UNSIGNED NOT NULL,
  amount_centavos INT UNSIGNED NOT NULL,
  status ENUM('pending','processing','paid','failed','cancelled') NOT NULL DEFAULT 'pending',
  reference VARCHAR(190) NULL,
  paid_at DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(contributor_profile_id) REFERENCES role_profiles(id)
) ENGINE=InnoDB;

CREATE TABLE promotions (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  pdf_id INT UNSIGNED NULL,
  plan_id INT UNSIGNED NULL,
  label VARCHAR(120) NOT NULL,
  offer_price_centavos INT UNSIGNED NOT NULL,
  starts_at DATETIME NOT NULL,
  ends_at DATETIME NOT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  CHECK ((pdf_id IS NULL) <> (plan_id IS NULL)),
  FOREIGN KEY(pdf_id) REFERENCES pdf_files(id),
  FOREIGN KEY(plan_id) REFERENCES candidate_plans(id)
) ENGINE=InnoDB;

CREATE TABLE refunds (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  payment_id BIGINT UNSIGNED NOT NULL,
  amount_centavos INT UNSIGNED NOT NULL,
  reason TEXT NOT NULL,
  status ENUM('pending','confirmed','failed') NOT NULL DEFAULT 'pending',
  confirmed_at DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(payment_id) REFERENCES payments(id)
) ENGINE=InnoDB;

CREATE TABLE admin_audit_log (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  admin_user_id INT UNSIGNED NOT NULL,
  action VARCHAR(100) NOT NULL,
  target_type VARCHAR(80) NOT NULL,
  target_id VARCHAR(80) NOT NULL,
  details JSON NULL,
  ip_address VARCHAR(45) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(admin_user_id) REFERENCES users(id),
  INDEX idx_admin_audit(created_at,action)
) ENGINE=InnoDB;

