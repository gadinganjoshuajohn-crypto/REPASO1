-- Apply after 2026_10_16_platform_upgrade.sql. Preserves all application data.
USE repaso_db;
CREATE TABLE IF NOT EXISTS eligibility_policies (
  role ENUM('candidate','contributor') PRIMARY KEY,
  evidence_required TINYINT(1) NOT NULL DEFAULT 0,
  evidence_instructions VARCHAR(500) NULL,
  allowed_mime_types VARCHAR(255) NOT NULL DEFAULT 'application/pdf,image/jpeg,image/png',
  max_file_mb TINYINT UNSIGNED NOT NULL DEFAULT 8,
  retention_days SMALLINT UNSIGNED NOT NULL DEFAULT 365,
  updated_by INT UNSIGNED NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY(updated_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;
INSERT INTO eligibility_policies(role,evidence_required,evidence_instructions) VALUES
('candidate',0,'Supporting evidence is optional unless an administrator changes this policy. Conceal unrelated sensitive information.'),
('contributor',1,'Upload an official results reference, certificate of passing, or professional credential. Conceal unrelated sensitive information.')
ON DUPLICATE KEY UPDATE role=VALUES(role);
