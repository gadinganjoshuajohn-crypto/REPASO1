-- REPASO ownership, catalog-management, upload-integrity, and payment hardening.
-- Apply after 2026_10_16_platform_upgrade.sql. Existing rows and entitlements are retained.
USE repaso_db;

ALTER TABLE pdf_files
  ADD COLUMN owner_type ENUM('contributor','repaso','uncertain') NOT NULL DEFAULT 'uncertain' AFTER contributor_id,
  ADD COLUMN uploaded_by_user_id INT UNSIGNED NULL AFTER owner_type,
  ADD COLUMN ownership_status ENUM('pending','verified','review_required') NOT NULL DEFAULT 'review_required' AFTER uploaded_by_user_id,
  ADD COLUMN ownership_watermark VARCHAR(80) NULL AFTER ownership_status,
  ADD COLUMN content_sha256 CHAR(64) NULL AFTER ownership_watermark,
  ADD COLUMN hash_status ENUM('pending','verified','missing','duplicate') NOT NULL DEFAULT 'pending' AFTER content_sha256,
  ADD COLUMN duplicate_of_pdf_id INT UNSIGNED NULL AFTER hash_status,
  ADD COLUMN pdf_version INT UNSIGNED NOT NULL DEFAULT 1 AFTER duplicate_of_pdf_id,
  ADD COLUMN archived_at DATETIME NULL AFTER pdf_version,
  ADD COLUMN archived_by_user_id INT UNSIGNED NULL AFTER archived_at,
  ADD UNIQUE KEY uq_pdf_content_sha256(content_sha256),
  ADD INDEX idx_pdf_owner_catalog(owner_type,status,archived_at),
  ADD CONSTRAINT fk_pdf_uploaded_by FOREIGN KEY(uploaded_by_user_id) REFERENCES users(id) ON DELETE SET NULL,
  ADD CONSTRAINT fk_pdf_duplicate FOREIGN KEY(duplicate_of_pdf_id) REFERENCES pdf_files(id) ON DELETE SET NULL,
  ADD CONSTRAINT fk_pdf_archived_by FOREIGN KEY(archived_by_user_id) REFERENCES users(id) ON DELETE SET NULL;

-- A contributor upload is attributable. Legacy admin uploads are deliberately uncertain until reviewed.
UPDATE pdf_files p JOIN users u ON u.id=p.contributor_id
SET p.uploaded_by_user_id=p.contributor_id,
    p.owner_type=CASE WHEN u.role='contributor' THEN 'contributor' ELSE 'uncertain' END,
    p.ownership_status=CASE WHEN u.role='contributor' THEN 'verified' ELSE 'review_required' END,
    p.ownership_watermark=CASE WHEN u.role='contributor' THEN u.fullname ELSE NULL END
WHERE p.uploaded_by_user_id IS NULL;

ALTER TABLE orders
  ADD COLUMN plan_name_snapshot VARCHAR(120) NULL AFTER plan_id,
  ADD COLUMN plan_description_snapshot TEXT NULL AFTER plan_name_snapshot,
  ADD COLUMN duration_days_snapshot SMALLINT UNSIGNED NULL AFTER plan_description_snapshot;

ALTER TABLE payments
  ADD COLUMN provider_payment_intent_id VARCHAR(190) NULL AFTER provider_payment_id,
  ADD UNIQUE KEY uq_provider_checkout(provider,provider_checkout_id);

ALTER TABLE payment_webhook_events
  ADD COLUMN processing_status ENUM('received','processing','processed','failed') NOT NULL DEFAULT 'received' AFTER payload_hash,
  ADD COLUMN attempts SMALLINT UNSIGNED NOT NULL DEFAULT 0 AFTER processing_status,
  ADD COLUMN last_error VARCHAR(255) NULL AFTER attempts,
  ADD COLUMN locked_at DATETIME NULL AFTER last_error;

ALTER TABLE refunds
  ADD COLUMN provider_refund_id VARCHAR(190) NULL AFTER payment_id,
  ADD COLUMN order_id BIGINT UNSIGNED NULL AFTER provider_refund_id,
  ADD UNIQUE KEY uq_provider_refund(provider_refund_id),
  ADD CONSTRAINT fk_refund_order FOREIGN KEY(order_id) REFERENCES orders(id);

CREATE TABLE pdf_acquisitions (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  pdf_id INT UNSIGNED NOT NULL,
  seller_name VARCHAR(190) NOT NULL,
  seller_contact VARCHAR(190) NULL,
  source_description TEXT NULL,
  amount_centavos INT UNSIGNED NOT NULL,
  acquired_on DATE NOT NULL,
  agreement_reference VARCHAR(190) NOT NULL,
  evidence_reference TEXT NOT NULL,
  rights_scope TEXT NOT NULL,
  rights_verified_at DATETIME NOT NULL,
  recorded_by_user_id INT UNSIGNED NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(pdf_id) REFERENCES pdf_files(id),
  FOREIGN KEY(recorded_by_user_id) REFERENCES users(id),
  INDEX idx_acquisition_pdf(pdf_id)
) ENGINE=InnoDB;

CREATE TABLE platform_revenue_ledger (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id BIGINT UNSIGNED NOT NULL,
  pdf_id INT UNSIGNED NULL,
  entry_type ENUM('repaso_pdf_sale','subscription','refund') NOT NULL,
  amount_centavos INT NOT NULL,
  environment ENUM('test','live','manual') NOT NULL,
  status ENUM('confirmed','reversed') NOT NULL DEFAULT 'confirmed',
  occurred_at DATETIME NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_platform_order_entry(order_id,entry_type),
  FOREIGN KEY(order_id) REFERENCES orders(id),
  FOREIGN KEY(pdf_id) REFERENCES pdf_files(id)
) ENGINE=InnoDB;

CREATE TABLE subscription_share_allocations (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id BIGINT UNSIGNED NOT NULL,
  status ENUM('unallocated','allocated','reversed') NOT NULL DEFAULT 'unallocated',
  reason VARCHAR(255) NOT NULL,
  allocation_snapshot JSON NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_subscription_allocation_order(order_id),
  FOREIGN KEY(order_id) REFERENCES orders(id)
) ENGINE=InnoDB;

