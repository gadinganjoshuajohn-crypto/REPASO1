-- Destructive rollback for the 2026-10-16 upgrade. Back up first.
USE repaso_db;
SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS admin_audit_log,refunds,promotions,payouts,earnings_ledger,contributor_agreements,usage_events,pdf_entitlements,payment_webhook_events,payments,orders,candidate_plans,activation_tokens,application_history,application_evidence,eligibility_applications,role_profiles;
ALTER TABLE subscriptions DROP COLUMN IF EXISTS candidate_profile_id,DROP COLUMN IF EXISTS order_id,DROP COLUMN IF EXISTS plan_id;
ALTER TABLE pdf_files DROP COLUMN IF EXISTS profession_id,DROP COLUMN IF EXISTS access_policy,DROP COLUMN IF EXISTS price_centavos,DROP COLUMN IF EXISTS individual_access_days,DROP COLUMN IF EXISTS subscription_included,DROP COLUMN IF EXISTS rights_status,DROP COLUMN IF EXISTS rights_note;
ALTER TABLE subjects DROP COLUMN IF EXISTS profession_id,DROP COLUMN IF EXISTS description,DROP COLUMN IF EXISTS is_active;
DROP TABLE IF EXISTS professions;
SET FOREIGN_KEY_CHECKS=1;

