<?php
require_once __DIR__.'/includes/bootstrap.php';
require_once __DIR__.'/includes/layout.php';
require_approved_profile('candidate');
$db=Database::connection();
$cover=pdf_cover_schema_ready($db)?'p.cover_filename,p.cover_position_x,p.cover_position_y,':'NULL cover_filename,50 cover_position_x,50 cover_position_y,';
$q=$db->prepare('SELECT b.page_number,b.created_at,p.id,p.title,'.$cover.'COALESCE(s.subject_name,c.category_name) subject,c.category_name category FROM bookmarks b JOIN pdf_files p ON p.id=b.pdf_id JOIN categories c ON c.id=p.category_id LEFT JOIN subjects s ON s.id=p.subject_id WHERE b.user_id=? ORDER BY b.created_at DESC');
$q->execute([user()['id']]);$rows=$q->fetchAll();
page_start('Bookmarks');
?>
<div class="section-heading saved-page-heading"><div><div class="eyebrow">Saved pages</div><h1>Bookmarks</h1><p class="muted">Return directly to important pages across your reviewer library.</p></div><a class="button ghost" href="<?=e(url('library.php'))?>">Browse library</a></div>
<?php if($rows):?><section class="saved-page-grid"><?php foreach($rows as $r):?><article class="saved-page-card"><?=reviewer_cover($r,'saved-page-cover')?><div class="saved-page-copy"><div class="saved-page-top"><span class="page-chip"><?=icon('bookmark',15)?> Page <?=(int)$r['page_number']?></span><span class="meta"><?=e(manila_time($r['created_at']))?></span></div><h2><?=e($r['title'])?></h2><p class="muted"><?=e($r['subject']??'Reviewer material')?></p><div class="saved-page-actions"><a class="button navy small" href="viewer.php?id=<?=(int)$r['id']?>&page=<?=(int)$r['page_number']?>">Open saved page <?=icon('chevron',15)?></a></div></div></article><?php endforeach;?></section><?php else:?><section class="empty-state saved-empty"><?=icon('bookmark',34)?><h2>No bookmarks yet</h2><p>While reading, select <strong>Bookmark page</strong> to keep an important page here.</p><a class="button gold" href="library.php">Open a reviewer</a></section><?php endif;?>
<?php page_end();
