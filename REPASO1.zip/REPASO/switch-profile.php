<?php
require_once __DIR__.'/includes/bootstrap.php';require_login();
if($_SERVER['REQUEST_METHOD']!=='POST')redirect('dashboard.php');verify_csrf();
$target=in_array($_POST['role']??'', ['candidate','contributor'],true)?$_POST['role']:'';
$db=Database::connection();if(!$db||!table_exists($db,'role_profiles')){http_response_code(409);exit('Profile switching requires the platform migration.');}
$q=$db->prepare('SELECT id FROM role_profiles WHERE user_id=? AND role=? AND status="approved" LIMIT 1');$q->execute([(int)user()['id'],$target]);
if(!$q->fetchColumn()){flash('error','That linked profile is not approved and active.');redirect(($target==='candidate'?'dashboard.php':'contributor/dashboard.php'));}
$_SESSION['user']['role']=$target;$_SESSION['last_profile_role']=$target;session_regenerate_id(true);
redirect($target==='candidate'?'dashboard.php':'contributor/dashboard.php');
