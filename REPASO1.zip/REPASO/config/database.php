<?php
declare(strict_types=1);

final class Database
{
    private static ?PDO $connection = null;

    public static function connection(): ?PDO
    {
        if (self::$connection instanceof PDO) {
            return self::$connection;
        }

        $host = getenv('REPASO_DB_HOST') ?: '127.0.0.1';
        $port = getenv('REPASO_DB_PORT') ?: '3306';
        $name = getenv('REPASO_DB_NAME') ?: 'repaso_db';
        $user = getenv('REPASO_DB_USER') ?: 'root';
        $pass = getenv('REPASO_DB_PASS') ?: '';

        try {
            self::$connection = new PDO(
                "mysql:host={$host};port={$port};dbname={$name};charset=utf8mb4",
                $user,
                $pass,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
        } catch (PDOException $exception) {
            error_log('[REPASO] Database unavailable: ' . $exception->getMessage());
            self::$connection = null;
        }

        return self::$connection;
    }
}
